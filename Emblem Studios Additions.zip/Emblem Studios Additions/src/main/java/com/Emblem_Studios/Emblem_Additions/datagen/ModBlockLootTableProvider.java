package com.Emblem_Studios.Emblem_Additions.datagen;

import com.Emblem_Studios.Emblem_Additions.block.ModBlocks;
import com.Emblem_Studios.Emblem_Additions.item.ModItems;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.loot.BlockLootSubProvider;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.IModBusEvent;
import net.minecraftforge.registries.RegistryObject;

import java.util.Set;

public class ModBlockLootTableProvider extends BlockLootSubProvider {
    protected ModBlockLootTableProvider(HolderLookup.Provider pRegistries) {
        super(Set.of(), FeatureFlags.REGISTRY.allFlags(), pRegistries);
    }

    @Override
    protected void generate() {
        dropSelf(ModBlocks.CRACKED_STONE_BRICK_STAIRS.get());
        this.add(ModBlocks.CRACKED_STONE_BRICK_SLAB.get(), block -> createSlabItemTable(ModBlocks.CRACKED_STONE_BRICK_SLAB.get()));
        dropSelf(ModBlocks.CRACKED_STONE_BRICK_WALL.get());
        dropSelf(ModBlocks.MOSSY_CHISILED_STONE_BRICKS.get());
        dropSelf(ModBlocks.CRACKED_CHISILED_STONE_BRICKS.get());
        dropSelf(ModBlocks.STONE_BRICK_PILLAR.get());
        dropSelf(ModBlocks.MOSSY_STONE_BRICK_PILLAR.get());
        dropSelf(ModBlocks.CRACKED_STONE_BRICK_PILLAR.get());
        dropSelf(ModBlocks.MOSSY_COBBLED_DEEPSLATE.get());
        dropSelf(ModBlocks.MOSSY_COBBLED_DEEPSLATE_STAIRS.get());
        this.add(ModBlocks.MOSSY_COBBLED_DEEPSLATE_SLAB.get(), block -> createSlabItemTable(ModBlocks.MOSSY_COBBLED_DEEPSLATE_SLAB.get()));
        dropSelf(ModBlocks.MOSSY_COBBLED_DEEPSLATE_WALL.get());
        dropSelf(ModBlocks.MOSSY_DEEPSLATE_BRICKS.get());
        dropSelf(ModBlocks.MOSSY_DEEPSLATE_BRICK_STAIRS.get());
        this.add(ModBlocks.MOSSY_DEEPSLATE_BRICK_SLAB.get(), block -> createSlabItemTable(ModBlocks.MOSSY_DEEPSLATE_BRICK_SLAB.get()));
        dropSelf(ModBlocks.MOSSY_DEEPSLATE_BRICK_WALL.get());
        dropSelf(ModBlocks.CRACKED_DEEPSLATE_BRICK_STAIRS.get());
        this.add(ModBlocks.CRACKED_DEEPSLATE_BRICK_SLAB.get(), block -> createSlabItemTable(ModBlocks.CRACKED_DEEPSLATE_BRICK_SLAB.get()));
        dropSelf(ModBlocks.CRACKED_DEEPSLATE_BRICK_WALL.get());
        dropSelf(ModBlocks.MOSSY_DEEPSLATE_TILES.get());
        dropSelf(ModBlocks.MOSSY_DEEPSLATE_TILE_STAIRS.get());
        this.add(ModBlocks.MOSSY_DEEPSLATE_TILE_SLAB.get(), block -> createSlabItemTable(ModBlocks.MOSSY_DEEPSLATE_TILE_SLAB.get()));
        dropSelf(ModBlocks.MOSSY_DEEPSLATE_TILE_WALL.get());
        dropSelf(ModBlocks.CRACKED_DEEPSLATE_TILE_STAIRS.get());
        this.add(ModBlocks.CRACKED_DEEPSLATE_TILE_SLAB.get(), block -> createSlabItemTable(ModBlocks.CRACKED_DEEPSLATE_TILE_SLAB.get()));
        dropSelf(ModBlocks.CRACKED_DEEPSLATE_TILE_WALL.get());
        dropSelf(ModBlocks.POLISHED_GRANITE_WALL.get());
        dropSelf(ModBlocks.GRANITE_BRICKS.get());
        dropSelf(ModBlocks.GRANITE_BRICK_STAIRS.get());
        this.add(ModBlocks.GRANITE_BRICK_SLAB.get(), block -> createSlabItemTable(ModBlocks.GRANITE_BRICK_SLAB.get()));
        dropSelf(ModBlocks.GRANITE_BRICK_WALL.get());
        dropSelf(ModBlocks.CHISELED_GRANITE_BRICKS.get());
        dropSelf(ModBlocks.POLISHED_DIORITE_WALL.get());
        dropSelf(ModBlocks.DIORITE_BRICKS.get());
        dropSelf(ModBlocks.DIORITE_BRICK_STAIRS.get());
        this.add(ModBlocks.DIORITE_BRICK_SLAB.get(), block -> createSlabItemTable(ModBlocks.DIORITE_BRICK_SLAB.get()));
        dropSelf(ModBlocks.DIORITE_BRICK_WALL.get());
        dropSelf(ModBlocks.CHISELED_DIORITE_BRICKS.get());
        dropSelf(ModBlocks.POLISHED_ANDESITE_WALL.get());
        dropSelf(ModBlocks.ANDESITE_BRICKS.get());
        dropSelf(ModBlocks.ANDESITE_BRICK_STAIRS.get());
        this.add(ModBlocks.ANDESITE_BRICK_SLAB.get(), block -> createSlabItemTable(ModBlocks.ANDESITE_BRICK_SLAB.get()));
        dropSelf(ModBlocks.ANDESITE_BRICK_WALL.get());
        dropSelf(ModBlocks.CHISELED_ANDESITE_BRICKS.get());
        dropSelf(ModBlocks.DRIPSTONE_STAIRS.get());
        this.add(ModBlocks.DRIPSTONE_SLAB.get(), block -> createSlabItemTable(ModBlocks.DRIPSTONE_SLAB.get()));
        dropSelf(ModBlocks.DRIPSTONE_WALL.get());
        dropSelf(ModBlocks.POLISHED_DRIPSTONE.get());
        dropSelf(ModBlocks.POLISHED_DRIPSTONE_STAIRS.get());
        this.add(ModBlocks.POLISHED_DRIPSTONE_SLAB.get(), block -> createSlabItemTable(ModBlocks.POLISHED_DRIPSTONE_SLAB.get()));
        dropSelf(ModBlocks.POLISHED_DRIPSTONE_WALL.get());
        dropSelf(ModBlocks.DRIPSTONE_BRICKS.get());
        dropSelf(ModBlocks.DRIPSTONE_BRICK_STAIRS.get());
        this.add(ModBlocks.DRIPSTONE_BRICK_SLAB.get(), block -> createSlabItemTable(ModBlocks.DRIPSTONE_BRICK_SLAB.get()));
        dropSelf(ModBlocks.DRIPSTONE_BRICK_WALL.get());
        dropSelf(ModBlocks.CHISELED_DRIPSTONE_BRICKS.get());
        dropSelf(ModBlocks.MOSSY_BRICKS.get());
        dropSelf(ModBlocks.MOSSY_BRICK_STAIRS.get());
        this.add(ModBlocks.MOSSY_BRICK_SLAB.get(), block -> createSlabItemTable(ModBlocks.MOSSY_BRICK_SLAB.get()));
        dropSelf(ModBlocks.MOSSY_BRICK_WALL.get());
        dropSelf(ModBlocks.CRACKED_BRICKS.get());
        dropSelf(ModBlocks.CRACKED_BRICK_STAIRS.get());
        this.add(ModBlocks.CRACKED_BRICK_SLAB.get(), block -> createSlabItemTable(ModBlocks.CRACKED_BRICK_SLAB.get()));
        dropSelf(ModBlocks.CRACKED_BRICK_WALL.get());
        dropSelf(ModBlocks.RUINED_BRICKS.get());
        dropSelf(ModBlocks.RUINED_BRICK_STAIRS.get());
        this.add(ModBlocks.RUINED_BRICK_SLAB.get(), block -> createSlabItemTable(ModBlocks.RUINED_BRICK_SLAB.get()));
        dropSelf(ModBlocks.RUINED_BRICK_WALL.get());
        dropWhenSilkTouch(ModBlocks.INFESTED_MOSSY_CHISILED_STONE_BRICKS.get());
        dropWhenSilkTouch(ModBlocks.INFESTED_CRACKED_CHISILED_STONE_BRICKS.get());
        dropWhenSilkTouch(ModBlocks.INFESTED_STONE_BRICK_PILLAR.get());
        dropWhenSilkTouch(ModBlocks.INFESTED_MOSSY_STONE_BRICK_PILLAR.get());
        dropWhenSilkTouch(ModBlocks.INFESTED_CRACKED_STONE_BRICK_PILLAR.get());
        dropSelf(ModBlocks.POLISHED_PRISMARINE.get());
        dropSelf(ModBlocks.POLISHED_PRISMARINE_STAIRS.get());
        this.add(ModBlocks.POLISHED_PRISMARINE_SLAB.get(), block -> createSlabItemTable(ModBlocks.POLISHED_PRISMARINE_SLAB.get()));
        dropSelf(ModBlocks.POLISHED_PRISMARINE_WALL.get());
        dropSelf(ModBlocks.PRISMARINE_BRICK_WALL.get());
        dropSelf(ModBlocks.CHISELED_PRISMARINE_BRICKS.get());
        dropSelf(ModBlocks.DARK_PRISMARINE_WALL.get());
        dropSelf(ModBlocks.ELDER_SEA_LANTERN.get());
        dropSelf(ModBlocks.ELDER_PRISMARINE.get());
        dropSelf(ModBlocks.ELDER_PRISMARINE_STAIRS.get());
        dropSelf(ModBlocks.ELDER_PRISMARINE_SLAB.get());
        dropSelf(ModBlocks.ELDER_PRISMARINE_WALL.get());
        dropSelf(ModBlocks.POLISHED_ELDER_PRISMARINE.get());
        dropSelf(ModBlocks.POLISHED_ELDER_PRISMARINE_STAIRS.get());
        dropSelf(ModBlocks.POLISHED_ELDER_PRISMARINE_SLAB.get());
        dropSelf(ModBlocks.POLISHED_ELDER_PRISMARINE_WALL.get());
        dropSelf(ModBlocks.ELDER_PRISMARINE_BRICKS.get());
        dropSelf(ModBlocks.ELDER_PRISMARINE_BRICK_STAIRS.get());
        dropSelf(ModBlocks.ELDER_PRISMARINE_BRICK_SLAB.get());
        dropSelf(ModBlocks.ELDER_PRISMARINE_BRICK_WALL.get());
        dropSelf(ModBlocks.CHISELED_ELDER_PRISMARINE_BRICKS.get());
        dropSelf(ModBlocks.DARK_ELDER_PRISMARINE.get());
        dropSelf(ModBlocks.DARK_ELDER_PRISMARINE_STAIRS.get());
        dropSelf(ModBlocks.DARK_ELDER_PRISMARINE_SLAB.get());
        dropSelf(ModBlocks.DARK_ELDER_PRISMARINE_WALL.get());

        dropSelf(ModBlocks.QUARTZ_BRICK_STAIRS.get());
        dropSelf(ModBlocks.WHITE_QUARTZ_TILES.get());

        dropSelf(ModBlocks.ROSE_QUARTZ_BLOCK.get());
        dropSelf(ModBlocks.ROSE_QUARTZ_STAIRS.get());
        dropSelf(ModBlocks.CHISELED_ROSE_QUARTZ_BLOCK.get());
        dropSelf(ModBlocks.ROSE_QUARTZ_PILLAR.get());
        dropSelf(ModBlocks.ROSE_QUARTZ_BRICKS.get());
        dropSelf(ModBlocks.ROSE_QUARTZ_BRICK_STAIRS.get());
        dropSelf(ModBlocks.ROSE_QUARTZ_TILES.get());
        dropSelf(ModBlocks.SMOOTH_ROSE_QUARTZ.get());
        dropSelf(ModBlocks.SMOOTH_ROSE_QUARTZ_STAIRS.get());

        dropSelf(ModBlocks.SMOKY_QUARTZ_BLOCK.get());
        dropSelf(ModBlocks.SMOKY_QUARTZ_STAIRS.get());
        dropSelf(ModBlocks.CHISELED_SMOKY_QUARTZ_BLOCK.get());
        dropSelf(ModBlocks.SMOKY_QUARTZ_PILLAR.get());
        dropSelf(ModBlocks.SMOKY_QUARTZ_BRICKS.get());
        dropSelf(ModBlocks.SMOKY_QUARTZ_BRICK_STAIRS.get());
        dropSelf(ModBlocks.SMOKY_QUARTZ_TILES.get());
        dropSelf(ModBlocks.SMOOTH_SMOKY_QUARTZ.get());
        dropSelf(ModBlocks.SMOOTH_SMOKY_QUARTZ_STAIRS.get());

        dropSelf(ModBlocks.SOUL_QUARTZ_BLOCK.get());
        dropSelf(ModBlocks.SOUL_QUARTZ_STAIRS.get());
        dropSelf(ModBlocks.CHISELED_SOUL_QUARTZ_BLOCK.get());
        dropSelf(ModBlocks.SOUL_QUARTZ_PILLAR.get());
        dropSelf(ModBlocks.SOUL_QUARTZ_BRICKS.get());
        dropSelf(ModBlocks.SOUL_QUARTZ_BRICK_STAIRS.get());
        dropSelf(ModBlocks.SOUL_QUARTZ_TILES.get());
        dropSelf(ModBlocks.SMOOTH_SOUL_QUARTZ.get());
        dropSelf(ModBlocks.SMOOTH_SOUL_QUARTZ_STAIRS.get());

        dropSelf(ModBlocks.POLISHED_AMETHYST.get());
        dropSelf(ModBlocks.POLISHED_AMETHYST_STAIRS.get());
        dropSelf(ModBlocks.CHISELED_AMETHYST_BLOCK.get());
        dropSelf(ModBlocks.AMETHYST_PILLAR.get());
        dropSelf(ModBlocks.AMETHYST_BRICKS.get());
        dropSelf(ModBlocks.AMETHYST_BRICK_STAIRS.get());
        dropSelf(ModBlocks.AMETHYST_TILES.get());
        dropSelf(ModBlocks.SMOOTH_AMETHYST.get());
        dropSelf(ModBlocks.SMOOTH_AMETHYST_STAIRS.get());

        dropSelf(ModBlocks.QUARTZ_TILES_WHITE_ROSE.get());
        dropSelf(ModBlocks.QUARTZ_TILES_WHITE_SMOKY.get());
        dropSelf(ModBlocks.QUARTZ_TILES_ROSE_SMOKY.get());
        dropSelf(ModBlocks.QUARTZ_TILES_WHITE_SOUL.get());
        dropSelf(ModBlocks.QUARTZ_TILES_SOUL_ROSE.get());
        dropSelf(ModBlocks.QUARTZ_TILES_SOUL_SMOKY.get());
        dropSelf(ModBlocks.QUARTZ_TILES_WHITE_AMETHYST.get());
        dropSelf(ModBlocks.QUARTZ_TILES_ROSE_AMETHYST.get());
        dropSelf(ModBlocks.QUARTZ_TILES_SOUL_AMETHYST.get());
        dropSelf(ModBlocks.QUARTZ_TILES_SMOKY_AMETHYST.get());

        dropSelf(ModBlocks.BLAZE_BLOCK.get());

        //dropSelf(ModBlocks.);

        this.add(ModBlocks.QUARTZ_BRICK_SLAB.get(),
                block -> createSlabItemTable(ModBlocks.QUARTZ_BRICK_SLAB.get()));

        this.add(ModBlocks.NETHER_ROSE_QUARTZ_ORE.get(),
                block -> createOreDrop(ModBlocks.ROSE_QUARTZ_BLOCK.get(), ModItems.ROSE_QUARTZ.get()));
        this.add(ModBlocks.ROSE_QUARTZ_SLAB.get(),
                block -> createSlabItemTable(ModBlocks.ROSE_QUARTZ_SLAB.get()));
        this.add(ModBlocks.ROSE_QUARTZ_BRICK_SLAB.get(),
                block -> createSlabItemTable(ModBlocks.ROSE_QUARTZ_BRICK_SLAB.get()));
        this.add(ModBlocks.SMOOTH_ROSE_QUARTZ_SLAB.get(),
                block -> createSlabItemTable(ModBlocks.SMOOTH_ROSE_QUARTZ_SLAB.get()));

        this.add(ModBlocks.NETHER_SMOKY_QUARTZ_ORE.get(),
                block -> createOreDrop(ModBlocks.SMOKY_QUARTZ_BLOCK.get(), ModItems.SMOKY_QUARTZ.get()));
        this.add(ModBlocks.SMOKY_QUARTZ_SLAB.get(),
                block -> createSlabItemTable(ModBlocks.SMOKY_QUARTZ_SLAB.get()));
        this.add(ModBlocks.SMOKY_QUARTZ_BRICK_SLAB.get(),
                block -> createSlabItemTable(ModBlocks.SMOKY_QUARTZ_BRICK_SLAB.get()));
        this.add(ModBlocks.SMOOTH_SMOKY_QUARTZ_SLAB.get(),
                block -> createSlabItemTable(ModBlocks.SMOOTH_SMOKY_QUARTZ_SLAB.get()));

        this.add(ModBlocks.SOUL_QUARTZ_SLAB.get(),
                block -> createSlabItemTable(ModBlocks.SOUL_QUARTZ_SLAB.get()));
        this.add(ModBlocks.SOUL_QUARTZ_BRICK_SLAB.get(),
                block -> createSlabItemTable(ModBlocks.SOUL_QUARTZ_BRICK_SLAB.get()));
        this.add(ModBlocks.SMOOTH_SOUL_QUARTZ_SLAB.get(),
                block -> createSlabItemTable(ModBlocks.SMOOTH_SOUL_QUARTZ_SLAB.get()));

        this.add(ModBlocks.POLISHED_AMETHYST_SLAB.get(),
                block -> createSlabItemTable(ModBlocks.POLISHED_AMETHYST_SLAB.get()));
        this.add(ModBlocks.AMETHYST_BRICK_SLAB.get(),
                block -> createSlabItemTable(ModBlocks.AMETHYST_BRICK_SLAB.get()));
        this.add(ModBlocks.SMOOTH_AMETHYST_SLAB.get(),
                block -> createSlabItemTable(ModBlocks.SMOOTH_AMETHYST_SLAB.get()));

        //this.add(ModBlocks.SLAB.get(), block -> createSlabItemTable(ModBlocks.SLAB.get()));
    }

    @Override
    protected Iterable<Block> getKnownBlocks() {
        return ModBlocks.BLOCKS.getEntries().stream().map(RegistryObject::get)::iterator;
    }
}
