package com.Emblem_Studios.Emblem_Additions.trim;

public class ModTrimPatterns {
}
