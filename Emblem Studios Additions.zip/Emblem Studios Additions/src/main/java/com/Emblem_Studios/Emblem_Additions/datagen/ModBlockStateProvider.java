package com.Emblem_Studios.Emblem_Additions.datagen;

import com.Emblem_Studios.Emblem_Additions.Emblem_Additions;
import com.Emblem_Studios.Emblem_Additions.block.ModBlocks;
import com.Emblem_Studios.Emblem_Additions.block.custom.QuartzTileBlock;
import net.minecraft.data.PackOutput;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraftforge.client.model.generators.BlockStateProvider;
import net.minecraftforge.client.model.generators.ConfiguredModel;
import net.minecraftforge.client.model.generators.ModelFile;
import net.minecraftforge.common.data.ExistingFileHelper;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlockStateProvider extends BlockStateProvider {
    public ModBlockStateProvider(PackOutput output, ExistingFileHelper exFileHelper) {
        super(output, Emblem_Additions.MOD_ID, exFileHelper);
    }

    @Override
    protected void registerStatesAndModels() {
        stairsBlock(ModBlocks.CRACKED_STONE_BRICK_STAIRS.get(), blockTexture(Blocks.CRACKED_STONE_BRICKS));
        blockItem(ModBlocks.CRACKED_STONE_BRICK_STAIRS);
        slabBlock(ModBlocks.CRACKED_STONE_BRICK_SLAB.get(), blockTexture(Blocks.CRACKED_STONE_BRICKS), blockTexture(Blocks.CRACKED_STONE_BRICKS));
        blockItem(ModBlocks.CRACKED_STONE_BRICK_SLAB);
        wallBlock(ModBlocks.CRACKED_STONE_BRICK_WALL.get(), blockTexture(Blocks.CRACKED_STONE_BRICKS));
        blockWithItem(ModBlocks.MOSSY_CHISILED_STONE_BRICKS);
        blockWithItem(ModBlocks.CRACKED_CHISILED_STONE_BRICKS);
        pillarBlock(ModBlocks.STONE_BRICK_PILLAR);
        blockItem(ModBlocks.STONE_BRICK_PILLAR);
        pillarBlock(ModBlocks.MOSSY_STONE_BRICK_PILLAR);
        blockItem(ModBlocks.MOSSY_STONE_BRICK_PILLAR);
        pillarBlock(ModBlocks.CRACKED_STONE_BRICK_PILLAR);
        blockItem(ModBlocks.CRACKED_STONE_BRICK_PILLAR);
//        blockWithItem(ModBlocks.INFESTED_MOSSY_CHISILED_STONE_BRICKS);
//        blockWithItem(ModBlocks.INFESTED_CRACKED_CHISILED_STONE_BRICKS);
//        pillarBlock(ModBlocks.INFESTED_STONE_BRICK_PILLAR);
//        blockItem(ModBlocks.INFESTED_STONE_BRICK_PILLAR);
//        pillarBlock(ModBlocks.INFESTED_MOSSY_STONE_BRICK_PILLAR);
//        blockItem(ModBlocks.INFESTED_MOSSY_STONE_BRICK_PILLAR);
//        pillarBlock(ModBlocks.INFESTED_CRACKED_STONE_BRICK_PILLAR);
//        blockItem(ModBlocks.INFESTED_CRACKED_STONE_BRICK_PILLAR);
        blockWithItem(ModBlocks.MOSSY_COBBLED_DEEPSLATE);
        stairsBlock(ModBlocks.MOSSY_COBBLED_DEEPSLATE_STAIRS.get(), blockTexture(ModBlocks.MOSSY_COBBLED_DEEPSLATE.get()));
        blockItem(ModBlocks.MOSSY_COBBLED_DEEPSLATE_STAIRS);
        slabBlock(ModBlocks.MOSSY_COBBLED_DEEPSLATE_SLAB.get(), blockTexture(ModBlocks.MOSSY_COBBLED_DEEPSLATE.get()), blockTexture(ModBlocks.MOSSY_COBBLED_DEEPSLATE.get()));
        blockItem(ModBlocks.MOSSY_COBBLED_DEEPSLATE_SLAB);
        wallBlock(ModBlocks.MOSSY_COBBLED_DEEPSLATE_WALL.get(), blockTexture(ModBlocks.MOSSY_COBBLED_DEEPSLATE.get()));
        blockWithItem(ModBlocks.MOSSY_DEEPSLATE_BRICKS);
        stairsBlock(ModBlocks.MOSSY_DEEPSLATE_BRICK_STAIRS.get(), blockTexture(ModBlocks.MOSSY_DEEPSLATE_BRICKS.get()));
        blockItem(ModBlocks.MOSSY_DEEPSLATE_BRICK_STAIRS);
        slabBlock(ModBlocks.MOSSY_DEEPSLATE_BRICK_SLAB.get(), blockTexture(ModBlocks.MOSSY_DEEPSLATE_BRICKS.get()), blockTexture(ModBlocks.MOSSY_DEEPSLATE_BRICKS.get()));
        blockItem(ModBlocks.MOSSY_DEEPSLATE_BRICK_SLAB);
        wallBlock(ModBlocks.MOSSY_DEEPSLATE_BRICK_WALL.get(), blockTexture(ModBlocks.MOSSY_DEEPSLATE_BRICKS.get()));
        stairsBlock(ModBlocks.CRACKED_DEEPSLATE_BRICK_STAIRS.get(), blockTexture(Blocks.CRACKED_DEEPSLATE_BRICKS));
        blockItem(ModBlocks.CRACKED_DEEPSLATE_BRICK_STAIRS);
        slabBlock(ModBlocks.CRACKED_DEEPSLATE_BRICK_SLAB.get(), blockTexture(Blocks.CRACKED_DEEPSLATE_BRICKS), blockTexture(Blocks.CRACKED_DEEPSLATE_BRICKS));
        blockItem(ModBlocks.CRACKED_DEEPSLATE_BRICK_SLAB);
        wallBlock(ModBlocks.CRACKED_DEEPSLATE_BRICK_WALL.get(), blockTexture(Blocks.CRACKED_DEEPSLATE_BRICKS));
        blockWithItem(ModBlocks.MOSSY_DEEPSLATE_TILES);
        stairsBlock(ModBlocks.MOSSY_DEEPSLATE_TILE_STAIRS.get(), blockTexture(ModBlocks.MOSSY_DEEPSLATE_TILES.get()));
        blockItem(ModBlocks.MOSSY_DEEPSLATE_TILE_STAIRS);
        slabBlock(ModBlocks.MOSSY_DEEPSLATE_TILE_SLAB.get(), blockTexture(ModBlocks.MOSSY_DEEPSLATE_TILES.get()), blockTexture(ModBlocks.MOSSY_DEEPSLATE_TILES.get()));
        blockItem(ModBlocks.MOSSY_DEEPSLATE_TILE_SLAB);
        wallBlock(ModBlocks.MOSSY_DEEPSLATE_TILE_WALL.get(), blockTexture(ModBlocks.MOSSY_DEEPSLATE_TILES.get()));
        stairsBlock(ModBlocks.CRACKED_DEEPSLATE_TILE_STAIRS.get(), blockTexture(Blocks.CRACKED_DEEPSLATE_TILES));
        blockItem(ModBlocks.CRACKED_DEEPSLATE_TILE_STAIRS);
        slabBlock(ModBlocks.CRACKED_DEEPSLATE_TILE_SLAB.get(), blockTexture(Blocks.CRACKED_DEEPSLATE_TILES), blockTexture(Blocks.CRACKED_DEEPSLATE_TILES));
        blockItem(ModBlocks.CRACKED_DEEPSLATE_TILE_SLAB);
        wallBlock(ModBlocks.CRACKED_DEEPSLATE_TILE_WALL.get(), blockTexture(Blocks.CRACKED_DEEPSLATE_TILES));
        wallBlock(ModBlocks.POLISHED_GRANITE_WALL.get(), blockTexture(Blocks.POLISHED_GRANITE));
        blockWithItem(ModBlocks.GRANITE_BRICKS);
        stairsBlock(ModBlocks.GRANITE_BRICK_STAIRS.get(), blockTexture(ModBlocks.GRANITE_BRICKS.get()));
        blockItem(ModBlocks.GRANITE_BRICK_STAIRS);
        slabBlock(ModBlocks.GRANITE_BRICK_SLAB.get(), blockTexture(ModBlocks.GRANITE_BRICKS.get()), blockTexture(ModBlocks.GRANITE_BRICKS.get()));
        blockItem(ModBlocks.GRANITE_BRICK_SLAB);
        wallBlock(ModBlocks.GRANITE_BRICK_WALL.get(), blockTexture(ModBlocks.GRANITE_BRICKS.get()));
        blockWithItem(ModBlocks.CHISELED_GRANITE_BRICKS);
        wallBlock(ModBlocks.POLISHED_DIORITE_WALL.get(), blockTexture(Blocks.POLISHED_DIORITE));
        blockWithItem(ModBlocks.DIORITE_BRICKS);
        stairsBlock(ModBlocks.DIORITE_BRICK_STAIRS.get(), blockTexture(ModBlocks.DIORITE_BRICKS.get()));
        blockItem(ModBlocks.DIORITE_BRICK_STAIRS);
        slabBlock(ModBlocks.DIORITE_BRICK_SLAB.get(), blockTexture(ModBlocks.DIORITE_BRICKS.get()), blockTexture(ModBlocks.DIORITE_BRICKS.get()));
        blockItem(ModBlocks.DIORITE_BRICK_SLAB);
        wallBlock(ModBlocks.DIORITE_BRICK_WALL.get(), blockTexture(ModBlocks.DIORITE_BRICKS.get()));
        blockWithItem(ModBlocks.CHISELED_DIORITE_BRICKS);
        wallBlock(ModBlocks.POLISHED_ANDESITE_WALL.get(), blockTexture(Blocks.POLISHED_ANDESITE));
        blockWithItem(ModBlocks.ANDESITE_BRICKS);
        stairsBlock(ModBlocks.ANDESITE_BRICK_STAIRS.get(), blockTexture(ModBlocks.ANDESITE_BRICKS.get()));
        blockItem(ModBlocks.ANDESITE_BRICK_STAIRS);
        slabBlock(ModBlocks.ANDESITE_BRICK_SLAB.get(), blockTexture(ModBlocks.ANDESITE_BRICKS.get()), blockTexture(ModBlocks.ANDESITE_BRICKS.get()));
        blockItem(ModBlocks.ANDESITE_BRICK_SLAB);
        wallBlock(ModBlocks.ANDESITE_BRICK_WALL.get(), blockTexture(ModBlocks.ANDESITE_BRICKS.get()));
        blockWithItem(ModBlocks.CHISELED_ANDESITE_BRICKS);
        stairsBlock(ModBlocks.DRIPSTONE_STAIRS.get(), blockTexture(Blocks.DRIPSTONE_BLOCK));
        blockItem(ModBlocks.DRIPSTONE_STAIRS);
        slabBlock(ModBlocks.DRIPSTONE_SLAB.get(), blockTexture(Blocks.DRIPSTONE_BLOCK), blockTexture(Blocks.DRIPSTONE_BLOCK));
        blockItem(ModBlocks.DRIPSTONE_SLAB);
        wallBlock(ModBlocks.DRIPSTONE_WALL.get(), blockTexture(Blocks.DRIPSTONE_BLOCK));
        blockWithItem(ModBlocks.POLISHED_DRIPSTONE);
        stairsBlock(ModBlocks.POLISHED_DRIPSTONE_STAIRS.get(), blockTexture(ModBlocks.POLISHED_DRIPSTONE.get()));
        blockItem(ModBlocks.POLISHED_DRIPSTONE_STAIRS);
        slabBlock(ModBlocks.POLISHED_DRIPSTONE_SLAB.get(), blockTexture(ModBlocks.POLISHED_DRIPSTONE.get()), blockTexture(ModBlocks.POLISHED_DRIPSTONE.get()));
        blockItem(ModBlocks.POLISHED_DRIPSTONE_SLAB);
        wallBlock(ModBlocks.POLISHED_DRIPSTONE_WALL.get(), blockTexture(ModBlocks.POLISHED_DRIPSTONE.get()));
        blockWithItem(ModBlocks.DRIPSTONE_BRICKS);
        stairsBlock(ModBlocks.DRIPSTONE_BRICK_STAIRS.get(), blockTexture(ModBlocks.DRIPSTONE_BRICKS.get()));
        blockItem(ModBlocks.DRIPSTONE_BRICK_STAIRS);
        slabBlock(ModBlocks.DRIPSTONE_BRICK_SLAB.get(), blockTexture(ModBlocks.DRIPSTONE_BRICKS.get()), blockTexture(ModBlocks.DRIPSTONE_BRICKS.get()));
        blockItem(ModBlocks.DRIPSTONE_BRICK_SLAB);
        wallBlock(ModBlocks.DRIPSTONE_BRICK_WALL.get(), blockTexture(ModBlocks.DRIPSTONE_BRICKS.get()));
        blockWithItem(ModBlocks.CHISELED_DRIPSTONE_BRICKS);
        blockWithItem(ModBlocks.MOSSY_BRICKS);
        stairsBlock(ModBlocks.MOSSY_BRICK_STAIRS.get(), blockTexture(ModBlocks.MOSSY_BRICKS.get()));
        blockItem(ModBlocks.MOSSY_BRICK_STAIRS);
        slabBlock(ModBlocks.MOSSY_BRICK_SLAB.get(), blockTexture(ModBlocks.MOSSY_BRICKS.get()), blockTexture(ModBlocks.MOSSY_BRICKS.get()));
        blockItem(ModBlocks.MOSSY_BRICK_SLAB);
        wallBlock(ModBlocks.MOSSY_BRICK_WALL.get(), blockTexture(ModBlocks.MOSSY_BRICKS.get()));
        blockWithItem(ModBlocks.CRACKED_BRICKS);
        stairsBlock(ModBlocks.CRACKED_BRICK_STAIRS.get(), blockTexture(ModBlocks.CRACKED_BRICKS.get()));
        blockItem(ModBlocks.CRACKED_BRICK_STAIRS);
        slabBlock(ModBlocks.CRACKED_BRICK_SLAB.get(), blockTexture(ModBlocks.CRACKED_BRICKS.get()), blockTexture(ModBlocks.CRACKED_BRICKS.get()));
        blockItem(ModBlocks.CRACKED_BRICK_SLAB);
        wallBlock(ModBlocks.CRACKED_BRICK_WALL.get(), blockTexture(ModBlocks.CRACKED_BRICKS.get()));
        blockWithItem(ModBlocks.RUINED_BRICKS);
        stairsBlock(ModBlocks.RUINED_BRICK_STAIRS.get(), blockTexture(ModBlocks.RUINED_BRICKS.get()));
        blockItem(ModBlocks.RUINED_BRICK_STAIRS);
        slabBlock(ModBlocks.RUINED_BRICK_SLAB.get(), blockTexture(ModBlocks.RUINED_BRICKS.get()), blockTexture(ModBlocks.RUINED_BRICKS.get()));
        blockItem(ModBlocks.RUINED_BRICK_SLAB);
        wallBlock(ModBlocks.RUINED_BRICK_WALL.get(), blockTexture(ModBlocks.RUINED_BRICKS.get()));

        blockWithItem(ModBlocks.POLISHED_PRISMARINE);
        stairsBlock(ModBlocks.POLISHED_PRISMARINE_STAIRS.get(), blockTexture(ModBlocks.POLISHED_PRISMARINE.get()));
        blockItem(ModBlocks.POLISHED_PRISMARINE_STAIRS);
        slabBlock(ModBlocks.POLISHED_PRISMARINE_SLAB.get(), blockTexture(ModBlocks.POLISHED_PRISMARINE.get()), blockTexture(ModBlocks.POLISHED_PRISMARINE.get()));
        blockItem(ModBlocks.POLISHED_PRISMARINE_SLAB);
        wallBlock(ModBlocks.POLISHED_PRISMARINE_WALL.get(), blockTexture(ModBlocks.POLISHED_PRISMARINE.get()));
        wallBlock(ModBlocks.PRISMARINE_BRICK_WALL.get(), blockTexture(Blocks.PRISMARINE_BRICKS));
        blockWithItem(ModBlocks.CHISELED_PRISMARINE_BRICKS);
        wallBlock(ModBlocks.DARK_PRISMARINE_WALL.get(), blockTexture(Blocks.DARK_PRISMARINE));

        blockWithItem(ModBlocks.ELDER_SEA_LANTERN);
        blockWithItem(ModBlocks.ELDER_PRISMARINE);
        stairsBlock(ModBlocks.ELDER_PRISMARINE_STAIRS.get(), blockTexture(ModBlocks.ELDER_PRISMARINE.get()));
        blockItem(ModBlocks.ELDER_PRISMARINE_STAIRS);
        slabBlock(ModBlocks.ELDER_PRISMARINE_SLAB.get(), blockTexture(ModBlocks.ELDER_PRISMARINE.get()), blockTexture(ModBlocks.ELDER_PRISMARINE.get()));
        blockItem(ModBlocks.ELDER_PRISMARINE_SLAB);
        wallBlock(ModBlocks.ELDER_PRISMARINE_WALL.get(), blockTexture(ModBlocks.ELDER_PRISMARINE.get()));
        blockWithItem(ModBlocks.POLISHED_ELDER_PRISMARINE);
        stairsBlock(ModBlocks.POLISHED_ELDER_PRISMARINE_STAIRS.get(), blockTexture(ModBlocks.POLISHED_ELDER_PRISMARINE.get()));
        blockItem(ModBlocks.POLISHED_ELDER_PRISMARINE_STAIRS);
        slabBlock(ModBlocks.POLISHED_ELDER_PRISMARINE_SLAB.get(), blockTexture(ModBlocks.POLISHED_ELDER_PRISMARINE.get()), blockTexture(ModBlocks.POLISHED_ELDER_PRISMARINE.get()));
        blockItem(ModBlocks.POLISHED_ELDER_PRISMARINE_SLAB);
        wallBlock(ModBlocks.POLISHED_ELDER_PRISMARINE_WALL.get(), blockTexture(ModBlocks.POLISHED_ELDER_PRISMARINE.get()));
        blockWithItem(ModBlocks.ELDER_PRISMARINE_BRICKS);
        stairsBlock(ModBlocks.ELDER_PRISMARINE_BRICK_STAIRS.get(), blockTexture(ModBlocks.ELDER_PRISMARINE_BRICKS.get()));
        blockItem(ModBlocks.ELDER_PRISMARINE_BRICK_STAIRS);
        slabBlock(ModBlocks.ELDER_PRISMARINE_BRICK_SLAB.get(), blockTexture(ModBlocks.ELDER_PRISMARINE_BRICKS.get()), blockTexture(ModBlocks.ELDER_PRISMARINE_BRICKS.get()));
        blockItem(ModBlocks.ELDER_PRISMARINE_BRICK_SLAB);
        wallBlock(ModBlocks.ELDER_PRISMARINE_BRICK_WALL.get(), blockTexture(ModBlocks.ELDER_PRISMARINE_BRICKS.get()));
        blockWithItem(ModBlocks.CHISELED_ELDER_PRISMARINE_BRICKS);
        blockWithItem(ModBlocks.DARK_ELDER_PRISMARINE);
        stairsBlock(ModBlocks.DARK_ELDER_PRISMARINE_STAIRS.get(), blockTexture(ModBlocks.DARK_ELDER_PRISMARINE.get()));
        blockItem(ModBlocks.DARK_ELDER_PRISMARINE_STAIRS);
        slabBlock(ModBlocks.DARK_ELDER_PRISMARINE_SLAB.get(), blockTexture(ModBlocks.DARK_ELDER_PRISMARINE.get()), blockTexture(ModBlocks.DARK_ELDER_PRISMARINE.get()));
        blockItem(ModBlocks.DARK_ELDER_PRISMARINE_SLAB);
        wallBlock(ModBlocks.DARK_ELDER_PRISMARINE_WALL.get(), blockTexture(ModBlocks.DARK_ELDER_PRISMARINE.get()));

        stairsBlock(ModBlocks.QUARTZ_BRICK_STAIRS.get(), blockTexture(Blocks.QUARTZ_BRICKS));
        blockItem(ModBlocks.QUARTZ_BRICK_STAIRS);
        slabBlock(ModBlocks.QUARTZ_BRICK_SLAB.get(), blockTexture(Blocks.QUARTZ_BRICKS), blockTexture(Blocks.QUARTZ_BRICKS));
        blockItem(ModBlocks.QUARTZ_BRICK_SLAB);
        blockWithItem(ModBlocks.WHITE_QUARTZ_TILES);

        blockWithItem(ModBlocks.NETHER_ROSE_QUARTZ_ORE);
        blockWithItem(ModBlocks.ROSE_QUARTZ_BLOCK);
        stairsBlock(ModBlocks.ROSE_QUARTZ_STAIRS.get(), blockTexture(ModBlocks.ROSE_QUARTZ_BLOCK.get()));
        blockItem(ModBlocks.ROSE_QUARTZ_STAIRS);
        slabBlock(ModBlocks.ROSE_QUARTZ_SLAB.get(), blockTexture(ModBlocks.ROSE_QUARTZ_BLOCK.get()), blockTexture(ModBlocks.ROSE_QUARTZ_BLOCK.get()));
        blockItem(ModBlocks.ROSE_QUARTZ_SLAB);
        blockWithItem(ModBlocks.CHISELED_ROSE_QUARTZ_BLOCK);
        pillarBlock(ModBlocks.ROSE_QUARTZ_PILLAR);
        blockItem(ModBlocks.ROSE_QUARTZ_PILLAR);
        blockWithItem(ModBlocks.ROSE_QUARTZ_BRICKS);
        stairsBlock(ModBlocks.ROSE_QUARTZ_BRICK_STAIRS.get(), blockTexture(ModBlocks.ROSE_QUARTZ_BRICKS.get()));
        blockItem(ModBlocks.ROSE_QUARTZ_BRICK_STAIRS);
        slabBlock(ModBlocks.ROSE_QUARTZ_BRICK_SLAB.get(), blockTexture(ModBlocks.ROSE_QUARTZ_BRICKS.get()), blockTexture(ModBlocks.ROSE_QUARTZ_BRICKS.get()));
        blockItem(ModBlocks.ROSE_QUARTZ_BRICK_SLAB);
        blockWithItem(ModBlocks.ROSE_QUARTZ_TILES);
        blockWithItem(ModBlocks.SMOOTH_ROSE_QUARTZ);
        stairsBlock(ModBlocks.SMOOTH_ROSE_QUARTZ_STAIRS.get(), blockTexture(ModBlocks.SMOOTH_ROSE_QUARTZ.get()));
        blockItem(ModBlocks.SMOOTH_ROSE_QUARTZ_STAIRS);
        slabBlock(ModBlocks.SMOOTH_ROSE_QUARTZ_SLAB.get(), blockTexture(ModBlocks.SMOOTH_ROSE_QUARTZ.get()), blockTexture(ModBlocks.SMOOTH_ROSE_QUARTZ.get()));
        blockItem(ModBlocks.SMOOTH_ROSE_QUARTZ_SLAB);

        blockWithItem(ModBlocks.NETHER_SMOKY_QUARTZ_ORE);
        blockWithItem(ModBlocks.SMOKY_QUARTZ_BLOCK);
        stairsBlock(ModBlocks.SMOKY_QUARTZ_STAIRS.get(), blockTexture(ModBlocks.SMOKY_QUARTZ_BLOCK.get()));
        blockItem(ModBlocks.SMOKY_QUARTZ_STAIRS);
        slabBlock(ModBlocks.SMOKY_QUARTZ_SLAB.get(), blockTexture(ModBlocks.SMOKY_QUARTZ_BLOCK.get()), blockTexture(ModBlocks.SMOKY_QUARTZ_BLOCK.get()));
        blockItem(ModBlocks.SMOKY_QUARTZ_SLAB);
        blockWithItem(ModBlocks.CHISELED_SMOKY_QUARTZ_BLOCK);
        pillarBlock(ModBlocks.SMOKY_QUARTZ_PILLAR);
        blockItem(ModBlocks.SMOKY_QUARTZ_PILLAR);
        blockWithItem(ModBlocks.SMOKY_QUARTZ_BRICKS);
        stairsBlock(ModBlocks.SMOKY_QUARTZ_BRICK_STAIRS.get(), blockTexture(ModBlocks.SMOKY_QUARTZ_BRICKS.get()));
        blockItem(ModBlocks.SMOKY_QUARTZ_BRICK_STAIRS);
        slabBlock(ModBlocks.SMOKY_QUARTZ_BRICK_SLAB.get(), blockTexture(ModBlocks.SMOKY_QUARTZ_BRICKS.get()), blockTexture(ModBlocks.SMOKY_QUARTZ_BRICKS.get()));
        blockItem(ModBlocks.SMOKY_QUARTZ_BRICK_SLAB);
        blockWithItem(ModBlocks.SMOKY_QUARTZ_TILES);
        blockWithItem(ModBlocks.SMOOTH_SMOKY_QUARTZ);
        stairsBlock(ModBlocks.SMOOTH_SMOKY_QUARTZ_STAIRS.get(), blockTexture(ModBlocks.SMOOTH_SMOKY_QUARTZ.get()));
        blockItem(ModBlocks.SMOOTH_SMOKY_QUARTZ_STAIRS);
        slabBlock(ModBlocks.SMOOTH_SMOKY_QUARTZ_SLAB.get(), blockTexture(ModBlocks.SMOOTH_SMOKY_QUARTZ.get()), blockTexture(ModBlocks.SMOOTH_SMOKY_QUARTZ.get()));
        blockItem(ModBlocks.SMOOTH_SMOKY_QUARTZ_SLAB);

        blockWithItem(ModBlocks.SOUL_QUARTZ_BLOCK);
        stairsBlock(ModBlocks.SOUL_QUARTZ_STAIRS.get(), blockTexture(ModBlocks.SOUL_QUARTZ_BLOCK.get()));
        blockItem(ModBlocks.SOUL_QUARTZ_STAIRS);
        slabBlock(ModBlocks.SOUL_QUARTZ_SLAB.get(), blockTexture(ModBlocks.SOUL_QUARTZ_BLOCK.get()), blockTexture(ModBlocks.SOUL_QUARTZ_BLOCK.get()));
        blockItem(ModBlocks.SOUL_QUARTZ_SLAB);
        blockWithItem(ModBlocks.CHISELED_SOUL_QUARTZ_BLOCK);
        pillarBlock(ModBlocks.SOUL_QUARTZ_PILLAR);
        blockItem(ModBlocks.SOUL_QUARTZ_PILLAR);
        blockWithItem(ModBlocks.SOUL_QUARTZ_BRICKS);
        stairsBlock(ModBlocks.SOUL_QUARTZ_BRICK_STAIRS.get(), blockTexture(ModBlocks.SOUL_QUARTZ_BRICKS.get()));
        blockItem(ModBlocks.SOUL_QUARTZ_BRICK_STAIRS);
        slabBlock(ModBlocks.SOUL_QUARTZ_BRICK_SLAB.get(), blockTexture(ModBlocks.SOUL_QUARTZ_BRICKS.get()), blockTexture(ModBlocks.SOUL_QUARTZ_BRICKS.get()));
        blockItem(ModBlocks.SOUL_QUARTZ_BRICK_SLAB);
        blockWithItem(ModBlocks.SOUL_QUARTZ_TILES);
        blockWithItem(ModBlocks.SMOOTH_SOUL_QUARTZ);
        stairsBlock(ModBlocks.SMOOTH_SOUL_QUARTZ_STAIRS.get(), blockTexture(ModBlocks.SMOOTH_SOUL_QUARTZ.get()));
        blockItem(ModBlocks.SMOOTH_SOUL_QUARTZ_STAIRS);
        slabBlock(ModBlocks.SMOOTH_SOUL_QUARTZ_SLAB.get(), blockTexture(ModBlocks.SMOOTH_SOUL_QUARTZ.get()), blockTexture(ModBlocks.SMOOTH_SOUL_QUARTZ.get()));
        blockItem(ModBlocks.SMOOTH_SOUL_QUARTZ_SLAB);

        blockWithItem(ModBlocks.POLISHED_AMETHYST);
        stairsBlock(ModBlocks.POLISHED_AMETHYST_STAIRS.get(), blockTexture(ModBlocks.POLISHED_AMETHYST.get()));
        blockItem(ModBlocks.POLISHED_AMETHYST_STAIRS);
        slabBlock(ModBlocks.POLISHED_AMETHYST_SLAB.get(), blockTexture(ModBlocks.POLISHED_AMETHYST.get()), blockTexture(ModBlocks.POLISHED_AMETHYST.get()));
        blockItem(ModBlocks.POLISHED_AMETHYST_SLAB);
        blockWithItem(ModBlocks.CHISELED_AMETHYST_BLOCK);
        pillarBlock(ModBlocks.AMETHYST_PILLAR);
        blockItem(ModBlocks.AMETHYST_PILLAR);
        blockWithItem(ModBlocks.AMETHYST_BRICKS);
        stairsBlock(ModBlocks.AMETHYST_BRICK_STAIRS.get(), blockTexture(ModBlocks.AMETHYST_BRICKS.get()));
        blockItem(ModBlocks.AMETHYST_BRICK_STAIRS);
        slabBlock(ModBlocks.AMETHYST_BRICK_SLAB.get(), blockTexture(ModBlocks.AMETHYST_BRICKS.get()), blockTexture(ModBlocks.AMETHYST_BRICKS.get()));
        blockItem(ModBlocks.AMETHYST_BRICK_SLAB);
        blockWithItem(ModBlocks.AMETHYST_TILES);
        blockWithItem(ModBlocks.SMOOTH_AMETHYST);
        stairsBlock(ModBlocks.SMOOTH_AMETHYST_STAIRS.get(), blockTexture(ModBlocks.SMOOTH_AMETHYST.get()));
        blockItem(ModBlocks.SMOOTH_AMETHYST_STAIRS);
        slabBlock(ModBlocks.SMOOTH_AMETHYST_SLAB.get(), blockTexture(ModBlocks.SMOOTH_AMETHYST.get()), blockTexture(ModBlocks.SMOOTH_AMETHYST.get()));
        blockItem(ModBlocks.SMOOTH_AMETHYST_SLAB);

        quartzTiles(ModBlocks.QUARTZ_TILES_WHITE_ROSE);
        quartzTiles(ModBlocks.QUARTZ_TILES_WHITE_SMOKY);
        quartzTiles(ModBlocks.QUARTZ_TILES_ROSE_SMOKY);
        quartzTiles(ModBlocks.QUARTZ_TILES_WHITE_SOUL);
        quartzTiles(ModBlocks.QUARTZ_TILES_SOUL_ROSE);
        quartzTiles(ModBlocks.QUARTZ_TILES_SOUL_SMOKY);
        quartzTiles(ModBlocks.QUARTZ_TILES_WHITE_AMETHYST);
        quartzTiles(ModBlocks.QUARTZ_TILES_ROSE_AMETHYST);
        quartzTiles(ModBlocks.QUARTZ_TILES_SOUL_AMETHYST);
        quartzTiles(ModBlocks.QUARTZ_TILES_SMOKY_AMETHYST);

        pillarBlock(ModBlocks.BLAZE_BLOCK);
        blockItem(ModBlocks.BLAZE_BLOCK);
        //blockWithItem(ModBlocks.);
    }

    private void quartzTiles(RegistryObject<QuartzTileBlock> blockRegistryObject) {
        getVariantBuilder(blockRegistryObject.get()).forAllStates(blockState -> {
            if(blockState.getValue(QuartzTileBlock.INVERTED)) {
                return new ConfiguredModel[]{new ConfiguredModel(models().cubeAll(ForgeRegistries.BLOCKS.getKey(blockRegistryObject.get()).getPath() + "_inverted",
                        ResourceLocation.fromNamespaceAndPath(Emblem_Additions.MOD_ID, "block/" + ForgeRegistries.BLOCKS.getKey(blockRegistryObject.get()).getPath() + "_inverted")))};
            } else {
                return new ConfiguredModel[]{new ConfiguredModel(models().cubeAll(ForgeRegistries.BLOCKS.getKey(blockRegistryObject.get()).getPath(),
                        ResourceLocation.fromNamespaceAndPath(Emblem_Additions.MOD_ID, "block/" + ForgeRegistries.BLOCKS.getKey(blockRegistryObject.get()).getPath())))};
            }
        });
        simpleBlockItem(blockRegistryObject.get(), models().cubeAll(ForgeRegistries.BLOCKS.getKey(blockRegistryObject.get()).getPath(),
                ResourceLocation.fromNamespaceAndPath(Emblem_Additions.MOD_ID, "block/" + ForgeRegistries.BLOCKS.getKey(blockRegistryObject.get()).getPath())));
    }

    private void blockWithItem(RegistryObject<Block> blockRegistryObject) {
        simpleBlockWithItem(blockRegistryObject.get(), cubeAll(blockRegistryObject.get()));
    }
    private void pillarBlock(RegistryObject<? extends RotatedPillarBlock> blockRegistryObject) {
        logBlock(blockRegistryObject.get());
    }
    private void blockItem(RegistryObject<? extends Block> blockRegistryObject) {
        simpleBlockItem(blockRegistryObject.get(), new ModelFile.UncheckedModelFile("emblem_stuff:block/" +
                ForgeRegistries.BLOCKS.getKey(blockRegistryObject.get()).getPath()));
    }
    private void blockItem(RegistryObject<? extends Block> blockRegistryObject, String appendix) {
        simpleBlockItem(blockRegistryObject.get(), new ModelFile.UncheckedModelFile("emblem_stuff:block/" +
                ForgeRegistries.BLOCKS.getKey(blockRegistryObject.get()).getPath() + appendix));
    }
}
