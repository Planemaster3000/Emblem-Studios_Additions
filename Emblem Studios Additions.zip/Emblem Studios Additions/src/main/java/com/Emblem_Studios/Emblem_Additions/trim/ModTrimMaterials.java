package com.Emblem_Studios.Emblem_Additions.trim;

import com.Emblem_Studios.Emblem_Additions.Emblem_Additions;
import com.Emblem_Studios.Emblem_Additions.item.ModItems;
import net.minecraft.Util;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.worldgen.BootstrapContext;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.chat.TextColor;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.armortrim.TrimMaterial;

import java.util.Map;

public class ModTrimMaterials {
    public static final ResourceKey<TrimMaterial> ROSE_QUARTZ =
            ResourceKey.create(Registries.TRIM_MATERIAL, ResourceLocation.fromNamespaceAndPath(Emblem_Additions.MOD_ID, "rose_quartz"));
    public static final ResourceKey<TrimMaterial> SMOKY_QUARTZ =
            ResourceKey.create(Registries.TRIM_MATERIAL, ResourceLocation.fromNamespaceAndPath(Emblem_Additions.MOD_ID, "smoky_quartz"));
    public static final ResourceKey<TrimMaterial> SOUL_QUARTZ =
            ResourceKey.create(Registries.TRIM_MATERIAL, ResourceLocation.fromNamespaceAndPath(Emblem_Additions.MOD_ID, "soul_quartz"));

    public static void bootstrap(BootstrapContext<TrimMaterial> context) {
        register(context, ROSE_QUARTZ, ModItems.ROSE_QUARTZ.get(), Style.EMPTY.withColor(TextColor.parseColor("#C888A8").getOrThrow()), 1.0f);
        register(context, SMOKY_QUARTZ, ModItems.SMOKY_QUARTZ.get(), Style.EMPTY.withColor(TextColor.parseColor("#404032").getOrThrow()), 0.3f);
        register(context, SOUL_QUARTZ, ModItems.SMOKY_QUARTZ.get(), Style.EMPTY.withColor(TextColor.parseColor("#70B0E0").getOrThrow()), 0.8f);
    }

    private static void register(BootstrapContext<TrimMaterial> context, ResourceKey<TrimMaterial> trimKey, Item item,
                                 Style style, float itemModelIndex) {
        TrimMaterial trimmaterial = TrimMaterial.create(trimKey.location().getPath(), item, itemModelIndex,
                Component.translatable(Util.makeDescriptionId("trim_material", trimKey.location())).withStyle(style), Map.of());
        context.register(trimKey, trimmaterial);
    }
}
