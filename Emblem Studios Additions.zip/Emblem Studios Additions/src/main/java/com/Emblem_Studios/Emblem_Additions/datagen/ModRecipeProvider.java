package com.Emblem_Studios.Emblem_Additions.datagen;

import com.Emblem_Studios.Emblem_Additions.Emblem_Additions;
import com.Emblem_Studios.Emblem_Additions.block.ModBlocks;
import com.Emblem_Studios.Emblem_Additions.item.ModItems;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.data.recipes.*;
import net.minecraft.nbt.Tag;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.SmeltingRecipe;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.common.Tags;
import net.minecraftforge.common.crafting.conditions.IConditionBuilder;

import java.util.concurrent.CompletableFuture;

public class ModRecipeProvider extends RecipeProvider implements IConditionBuilder {
    public ModRecipeProvider(PackOutput pOutput, CompletableFuture<HolderLookup.Provider> pRegistries) {
        super(pOutput, pRegistries);
    }

    @Override
    protected void buildRecipes(RecipeOutput pRecipeOutput) {
        //Recipe Builders must start here

        twoByTwoPackingUnpacking(pRecipeOutput, RecipeCategory.MISC, ModItems.MOSS_CLUMP.get(), Blocks.MOSS_BLOCK);
        stairSlabWallRecipes(pRecipeOutput,
                Blocks.CRACKED_STONE_BRICKS,
                ModBlocks.CRACKED_STONE_BRICK_STAIRS.get(),
                ModBlocks.CRACKED_STONE_BRICK_SLAB.get(),
                ModBlocks.CRACKED_STONE_BRICK_WALL.get()
        );
        //Stone Brick
        chiseledBlockRecipe(pRecipeOutput, Blocks.MOSSY_STONE_BRICKS, Blocks.MOSSY_STONE_BRICK_SLAB, ModBlocks.MOSSY_CHISILED_STONE_BRICKS.get());
        chiseledBlockRecipe(pRecipeOutput, Blocks.CRACKED_STONE_BRICKS, ModBlocks.CRACKED_STONE_BRICK_SLAB.get(), ModBlocks.CRACKED_CHISILED_STONE_BRICKS.get());
        pillarBlockRecipe(pRecipeOutput, Blocks.STONE_BRICKS, ModBlocks.STONE_BRICK_PILLAR.get());
        pillarBlockRecipe(pRecipeOutput, Blocks.MOSSY_STONE_BRICKS, ModBlocks.MOSSY_STONE_BRICK_PILLAR.get());
        pillarBlockRecipe(pRecipeOutput, Blocks.CRACKED_STONE_BRICKS, ModBlocks.CRACKED_STONE_BRICK_PILLAR.get());
        //Deepslate
        mossyRecipes(pRecipeOutput, Blocks.COBBLED_DEEPSLATE, ModBlocks.MOSSY_COBBLED_DEEPSLATE.get());
        stairSlabWallRecipes(pRecipeOutput,
                ModBlocks.MOSSY_COBBLED_DEEPSLATE.get(),
                ModBlocks.MOSSY_COBBLED_DEEPSLATE_STAIRS.get(),
                ModBlocks.MOSSY_COBBLED_DEEPSLATE_SLAB.get(),
                ModBlocks.MOSSY_COBBLED_DEEPSLATE_WALL.get()
        );
        mossyRecipes(pRecipeOutput, Blocks.DEEPSLATE_BRICKS, ModBlocks.MOSSY_DEEPSLATE_BRICKS.get());
        stairSlabWallRecipes(pRecipeOutput,
                ModBlocks.MOSSY_DEEPSLATE_BRICKS.get(),
                ModBlocks.MOSSY_DEEPSLATE_BRICK_STAIRS.get(),
                ModBlocks.MOSSY_DEEPSLATE_BRICK_SLAB.get(),
                ModBlocks.MOSSY_DEEPSLATE_BRICK_WALL.get()
        );
        stairSlabWallRecipes(pRecipeOutput,
                Blocks.CRACKED_DEEPSLATE_BRICKS,
                ModBlocks.CRACKED_DEEPSLATE_BRICK_STAIRS.get(),
                ModBlocks.CRACKED_DEEPSLATE_BRICK_SLAB.get(),
                ModBlocks.CRACKED_DEEPSLATE_BRICK_WALL.get()
        );
        mossyRecipes(pRecipeOutput, Blocks.DEEPSLATE_TILES, ModBlocks.MOSSY_DEEPSLATE_TILES.get());
        stairSlabWallRecipes(pRecipeOutput,
                ModBlocks.MOSSY_DEEPSLATE_TILES.get(),
                ModBlocks.MOSSY_DEEPSLATE_TILE_STAIRS.get(),
                ModBlocks.MOSSY_DEEPSLATE_TILE_SLAB.get(),
                ModBlocks.MOSSY_DEEPSLATE_TILE_WALL.get()
        );
        stairSlabWallRecipes(pRecipeOutput,
                Blocks.CRACKED_DEEPSLATE_TILES,
                ModBlocks.CRACKED_DEEPSLATE_TILE_STAIRS.get(),
                ModBlocks.CRACKED_DEEPSLATE_TILE_SLAB.get(),
                ModBlocks.CRACKED_DEEPSLATE_TILE_WALL.get()
        );
        //Stone Trio
        stoneVariantRecipesBuilder(pRecipeOutput,
                Blocks.GRANITE, Blocks.POLISHED_GRANITE, ModBlocks.POLISHED_GRANITE_WALL.get(), ModBlocks.GRANITE_BRICKS.get(),
                ModBlocks.GRANITE_BRICK_STAIRS.get(), ModBlocks.GRANITE_BRICK_SLAB.get(), ModBlocks.GRANITE_BRICK_WALL.get(), ModBlocks.CHISELED_GRANITE_BRICKS.get()
                );
        stoneVariantRecipesBuilder(pRecipeOutput,
                Blocks.DIORITE, Blocks.POLISHED_DIORITE, ModBlocks.POLISHED_DIORITE_WALL.get(), ModBlocks.DIORITE_BRICKS.get(),
                ModBlocks.DIORITE_BRICK_STAIRS.get(), ModBlocks.DIORITE_BRICK_SLAB.get(), ModBlocks.DIORITE_BRICK_WALL.get(), ModBlocks.CHISELED_DIORITE_BRICKS.get()
        );
        stoneVariantRecipesBuilder(pRecipeOutput,
                Blocks.ANDESITE, Blocks.POLISHED_ANDESITE, ModBlocks.POLISHED_ANDESITE_WALL.get(), ModBlocks.ANDESITE_BRICKS.get(),
                ModBlocks.ANDESITE_BRICK_STAIRS.get(), ModBlocks.ANDESITE_BRICK_SLAB.get(), ModBlocks.ANDESITE_BRICK_WALL.get(), ModBlocks.CHISELED_ANDESITE_BRICKS.get()
        );
        //Dripstone
        dripstoneRecipesBuilder(pRecipeOutput,
                Blocks.DRIPSTONE_BLOCK, ModBlocks.DRIPSTONE_STAIRS.get(), ModBlocks.DRIPSTONE_SLAB.get(), ModBlocks.DRIPSTONE_WALL.get(),
                ModBlocks.POLISHED_DRIPSTONE.get(), ModBlocks.POLISHED_DRIPSTONE_STAIRS.get(), ModBlocks.POLISHED_DRIPSTONE_SLAB.get(), ModBlocks.POLISHED_DRIPSTONE_WALL.get(),
                ModBlocks.DRIPSTONE_BRICKS.get(), ModBlocks.DRIPSTONE_BRICK_STAIRS.get(), ModBlocks.DRIPSTONE_BRICK_SLAB.get(), ModBlocks.DRIPSTONE_BRICK_WALL.get(),
                ModBlocks.CHISELED_DRIPSTONE_BRICKS.get()
                );
        //Brick
        brickVariantRecipesBuilder(pRecipeOutput, Blocks.BRICKS,
                ModBlocks.MOSSY_BRICKS.get(), ModBlocks.MOSSY_BRICK_STAIRS.get(), ModBlocks.MOSSY_BRICK_SLAB.get(), ModBlocks.MOSSY_BRICK_WALL.get(),
                ModBlocks.CRACKED_BRICKS.get(), ModBlocks.CRACKED_BRICK_STAIRS.get(), ModBlocks.CRACKED_BRICK_SLAB.get(), ModBlocks.CRACKED_BRICK_WALL.get(),
                ModBlocks.RUINED_BRICKS.get(), ModBlocks.RUINED_BRICK_STAIRS.get(), ModBlocks.RUINED_BRICK_SLAB.get(), ModBlocks.RUINED_BRICK_WALL.get()
                );
        //Prismarine
        prismarineRecipeBuilder(pRecipeOutput, Blocks.PRISMARINE,
                ModBlocks.POLISHED_PRISMARINE.get(), ModBlocks.POLISHED_PRISMARINE_STAIRS.get(), ModBlocks.POLISHED_PRISMARINE_SLAB.get(), ModBlocks.POLISHED_PRISMARINE_WALL.get(),
                Blocks.PRISMARINE_BRICKS, Blocks.PRISMARINE_BRICK_SLAB, ModBlocks.PRISMARINE_BRICK_WALL.get(), ModBlocks.CHISELED_PRISMARINE_BRICKS.get(), Blocks.DARK_PRISMARINE, ModBlocks.DARK_PRISMARINE_WALL.get());
        elderPrismarineRecipeBuilder(pRecipeOutput, ModItems.ELDER_PRISMARINE_SHARD.get(),
                ModBlocks.ELDER_PRISMARINE.get(), ModBlocks.ELDER_PRISMARINE_STAIRS.get(), ModBlocks.ELDER_PRISMARINE_SLAB.get(), ModBlocks.ELDER_PRISMARINE_WALL.get(), ModBlocks.ELDER_SEA_LANTERN.get(),
                ModBlocks.POLISHED_ELDER_PRISMARINE.get(), ModBlocks.POLISHED_ELDER_PRISMARINE_STAIRS.get(), ModBlocks.POLISHED_ELDER_PRISMARINE_SLAB.get(), ModBlocks.POLISHED_ELDER_PRISMARINE_WALL.get(),
                ModBlocks.ELDER_PRISMARINE_BRICKS.get(), ModBlocks.ELDER_PRISMARINE_BRICK_STAIRS.get(),  ModBlocks.ELDER_PRISMARINE_BRICK_SLAB.get(), ModBlocks.ELDER_PRISMARINE_BRICK_WALL.get(), ModBlocks.CHISELED_ELDER_PRISMARINE_BRICKS.get(),
                ModBlocks.DARK_ELDER_PRISMARINE.get(), ModBlocks.DARK_ELDER_PRISMARINE_STAIRS.get(), ModBlocks.DARK_ELDER_PRISMARINE_SLAB.get(), ModBlocks.DARK_ELDER_PRISMARINE_WALL.get()
                );
        //Quartz
        twoByTwoPackingUnpacking(pRecipeOutput, RecipeCategory.BUILDING_BLOCKS, Items.QUARTZ, Blocks.QUARTZ_BLOCK);
        brickStairSlabRecipes(pRecipeOutput, Blocks.QUARTZ_BRICKS, Blocks.QUARTZ_BLOCK, ModBlocks.QUARTZ_BRICK_STAIRS.get(), ModBlocks.QUARTZ_BRICK_SLAB.get());
        stoneCutting(pRecipeOutput, Blocks.QUARTZ_BLOCK, ModBlocks.WHITE_QUARTZ_TILES.get());
        twoByTwoPackingUnpacking(pRecipeOutput, RecipeCategory.BUILDING_BLOCKS, ModItems.ROSE_QUARTZ.get(), ModBlocks.ROSE_QUARTZ_BLOCK.get());
        quartzRecipesBuilder(pRecipeOutput,
                ModBlocks.ROSE_QUARTZ_BLOCK.get(),
                ModBlocks.ROSE_QUARTZ_STAIRS.get(),
                ModBlocks.ROSE_QUARTZ_SLAB.get(),
                ModBlocks.CHISELED_ROSE_QUARTZ_BLOCK.get(),
                ModBlocks.ROSE_QUARTZ_PILLAR.get(),
                ModBlocks.ROSE_QUARTZ_BRICKS.get(),
                ModBlocks.ROSE_QUARTZ_BRICK_STAIRS.get(),
                ModBlocks.ROSE_QUARTZ_BRICK_SLAB.get(),
                ModBlocks.ROSE_QUARTZ_TILES.get(),
                ModBlocks.SMOOTH_ROSE_QUARTZ.get(),
                ModBlocks.SMOOTH_ROSE_QUARTZ_STAIRS.get(),
                ModBlocks.SMOOTH_ROSE_QUARTZ_SLAB.get()
                );
        twoByTwoPackingUnpacking(pRecipeOutput, RecipeCategory.BUILDING_BLOCKS, ModItems.SMOKY_QUARTZ.get(), ModBlocks.SMOKY_QUARTZ_BLOCK.get());
        quartzRecipesBuilder(pRecipeOutput,
                ModBlocks.SMOKY_QUARTZ_BLOCK.get(),
                ModBlocks.SMOKY_QUARTZ_STAIRS.get(),
                ModBlocks.SMOKY_QUARTZ_SLAB.get(),
                ModBlocks.CHISELED_SMOKY_QUARTZ_BLOCK.get(),
                ModBlocks.SMOKY_QUARTZ_PILLAR.get(),
                ModBlocks.SMOKY_QUARTZ_BRICKS.get(),
                ModBlocks.SMOKY_QUARTZ_BRICK_STAIRS.get(),
                ModBlocks.SMOKY_QUARTZ_BRICK_SLAB.get(),
                ModBlocks.SMOKY_QUARTZ_TILES.get(),
                ModBlocks.SMOOTH_SMOKY_QUARTZ.get(),
                ModBlocks.SMOOTH_SMOKY_QUARTZ_STAIRS.get(),
                ModBlocks.SMOOTH_SMOKY_QUARTZ_SLAB.get()
        );
        twoByTwoPackingUnpacking(pRecipeOutput, RecipeCategory.BUILDING_BLOCKS, ModItems.SOUL_QUARTZ.get(), ModBlocks.SOUL_QUARTZ_BLOCK.get());
        quartzRecipesBuilder(pRecipeOutput,
                ModBlocks.SOUL_QUARTZ_BLOCK.get(),
                ModBlocks.SOUL_QUARTZ_STAIRS.get(),
                ModBlocks.SOUL_QUARTZ_SLAB.get(),
                ModBlocks.CHISELED_SOUL_QUARTZ_BLOCK.get(),
                ModBlocks.SOUL_QUARTZ_PILLAR.get(),
                ModBlocks.SOUL_QUARTZ_BRICKS.get(),
                ModBlocks.SOUL_QUARTZ_BRICK_STAIRS.get(),
                ModBlocks.SOUL_QUARTZ_BRICK_SLAB.get(),
                ModBlocks.SOUL_QUARTZ_TILES.get(),
                ModBlocks.SMOOTH_SOUL_QUARTZ.get(),
                ModBlocks.SMOOTH_SOUL_QUARTZ_STAIRS.get(),
                ModBlocks.SMOOTH_SOUL_QUARTZ_SLAB.get()
        );
        amethystQuartzRecipesBuilder(pRecipeOutput,
                Blocks.AMETHYST_BLOCK,
                ModBlocks.POLISHED_AMETHYST.get(),
                ModBlocks.POLISHED_AMETHYST_STAIRS.get(),
                ModBlocks.POLISHED_AMETHYST_SLAB.get(),
                ModBlocks.CHISELED_AMETHYST_BLOCK.get(),
                ModBlocks.AMETHYST_PILLAR.get(),
                ModBlocks.AMETHYST_BRICKS.get(),
                ModBlocks.AMETHYST_BRICK_STAIRS.get(),
                ModBlocks.AMETHYST_BRICK_SLAB.get(),
                ModBlocks.AMETHYST_TILES.get(),
                ModBlocks.SMOOTH_AMETHYST.get(),
                ModBlocks.SMOOTH_AMETHYST_STAIRS.get(),
                ModBlocks.SMOOTH_AMETHYST_SLAB.get()
        );
        //Tiles
        quartzTilesRecipes(pRecipeOutput,
                ModBlocks.QUARTZ_TILES_WHITE_ROSE.get(),
                Items.QUARTZ,
                ModItems.ROSE_QUARTZ.get(),
                Blocks.QUARTZ_BLOCK,
                ModBlocks.ROSE_QUARTZ_BLOCK.get()
        );
        quartzTilesRecipes(pRecipeOutput,
                ModBlocks.QUARTZ_TILES_WHITE_SMOKY.get(),
                Items.QUARTZ,
                ModItems.SMOKY_QUARTZ.get(),
                Blocks.QUARTZ_BLOCK,
                ModBlocks.SMOKY_QUARTZ_BLOCK.get()
        );
        quartzTilesRecipes(pRecipeOutput,
                ModBlocks.QUARTZ_TILES_ROSE_SMOKY.get(),
                ModItems.ROSE_QUARTZ.get(),
                ModItems.SMOKY_QUARTZ.get(),
                ModBlocks.ROSE_QUARTZ_BLOCK.get(),
                ModBlocks.SMOKY_QUARTZ_BLOCK.get()
        );
        quartzTilesRecipes(pRecipeOutput,
                ModBlocks.QUARTZ_TILES_WHITE_SOUL.get(),
                Items.QUARTZ,
                ModItems.SOUL_QUARTZ.get(),
                Blocks.QUARTZ_BLOCK,
                ModBlocks.SOUL_QUARTZ_BLOCK.get()
        );
        quartzTilesRecipes(pRecipeOutput,
                ModBlocks.QUARTZ_TILES_SOUL_ROSE.get(),
                ModItems.SOUL_QUARTZ.get(),
                ModItems.ROSE_QUARTZ.get(),
                ModBlocks.SOUL_QUARTZ_BLOCK.get(),
                ModBlocks.ROSE_QUARTZ_BLOCK.get()
        );
        quartzTilesRecipes(pRecipeOutput,
                ModBlocks.QUARTZ_TILES_SOUL_SMOKY.get(),
                ModItems.SOUL_QUARTZ.get(),
                ModItems.SMOKY_QUARTZ.get(),
                ModBlocks.SOUL_QUARTZ_BLOCK.get(),
                ModBlocks.SMOKY_QUARTZ_BLOCK.get()
        );
        quartzTilesRecipes(pRecipeOutput,
                ModBlocks.QUARTZ_TILES_WHITE_AMETHYST.get(),
                Items.QUARTZ,
                Items.AMETHYST_SHARD,
                Blocks.QUARTZ_BLOCK,
                ModBlocks.POLISHED_AMETHYST.get()
        );
        quartzTilesRecipes(pRecipeOutput,
                ModBlocks.QUARTZ_TILES_ROSE_AMETHYST.get(),
                ModItems.ROSE_QUARTZ.get(),
                Items.AMETHYST_SHARD,
                ModBlocks.ROSE_QUARTZ_BLOCK.get(),
                ModBlocks.POLISHED_AMETHYST.get()
        );
        quartzTilesRecipes(pRecipeOutput,
                ModBlocks.QUARTZ_TILES_SMOKY_AMETHYST.get(),
                ModItems.SMOKY_QUARTZ.get(),
                Items.AMETHYST_SHARD,
                ModBlocks.SMOKY_QUARTZ_BLOCK.get(),
                ModBlocks.POLISHED_AMETHYST.get()
        );
        quartzTilesRecipes(pRecipeOutput,
                ModBlocks.QUARTZ_TILES_SOUL_AMETHYST.get(),
                ModItems.SOUL_QUARTZ.get(),
                Items.AMETHYST_SHARD,
                ModBlocks.SOUL_QUARTZ_BLOCK.get(),
                ModBlocks.POLISHED_AMETHYST.get()
        );
        //Misc
        compactingUnpacking(pRecipeOutput, RecipeCategory.MISC, Items.BLAZE_ROD, ModBlocks.BLAZE_BLOCK.get());

    }
    protected static void quartzTilesRecipes(RecipeOutput pRecipeOutput, ItemLike pResult, ItemLike pItemOne, ItemLike pItemTwo, ItemLike pBlockOne, ItemLike pBlockTwo) {
        ShapedRecipeBuilder.shaped(RecipeCategory.BUILDING_BLOCKS, pResult)
                .pattern("#X")
                .pattern("X#")
                .define('#', pItemOne)
                .define('X', pItemTwo)
                .group(getItemName(pResult))
                .unlockedBy(getHasName(pItemOne), has(pItemOne))
                .unlockedBy(getHasName(pItemTwo), has(pItemTwo))
                .save(pRecipeOutput);
        ShapedRecipeBuilder.shaped(RecipeCategory.BUILDING_BLOCKS, pResult, 4)
                .pattern("#X")
                .pattern("X#")
                .define('#', pBlockOne)
                .define('X', pBlockTwo)
                .group(getItemName(pResult))
                .unlockedBy(getHasName(pBlockOne), has(pBlockOne))
                .unlockedBy(getHasName(pBlockTwo), has(pBlockTwo))
                .save(pRecipeOutput, Emblem_Additions.MOD_ID + ":" + getItemName(pResult) + "_from_blocks");
    }
    protected static void quartzRecipesBuilder(RecipeOutput recipeOutput,
                                               ItemLike baseBlock, ItemLike stairsItem, ItemLike slabItem,
                                               ItemLike chiseledBlock, ItemLike pillarBlock,
                                               ItemLike brickBlock, ItemLike brickStairsItem, ItemLike brickSlabItem,
                                               ItemLike tileBlock,
                                               ItemLike smoothBlock, ItemLike smoothStairsItem, ItemLike smoothSlabItem) {
        stairSlabRecipes(recipeOutput, baseBlock, stairsItem, slabItem);
        polishedBlockRecipes(recipeOutput, baseBlock, brickBlock);
        brickStairSlabRecipes(recipeOutput, brickBlock, baseBlock, brickStairsItem, brickSlabItem);
        chiseledBlockRecipe(recipeOutput, baseBlock, slabItem, chiseledBlock);
        pillarBlockRecipe(recipeOutput, baseBlock, pillarBlock);
        stoneCutting(recipeOutput, baseBlock, tileBlock);
        smeltingRecipe(recipeOutput, baseBlock, smoothBlock, 0.1f);
        stairSlabRecipes(recipeOutput, smoothBlock, smoothStairsItem, smoothSlabItem);
    }
    protected static void amethystQuartzRecipesBuilder(RecipeOutput recipeOutput,
                                                       ItemLike baseBlock, ItemLike polishedBlock, ItemLike stairsItem, ItemLike slabItem,
                                                       ItemLike chiseledBlock, ItemLike pillarBlock,
                                                       ItemLike brickBlock, ItemLike brickStairsItem, ItemLike brickSlabItem,
                                                       ItemLike tileBlock,
                                                       ItemLike smoothBlock, ItemLike smoothStairsItem, ItemLike smoothSlabItem) {
        quartzRecipesBuilder(recipeOutput, polishedBlock, stairsItem, slabItem, chiseledBlock, pillarBlock, brickBlock, brickStairsItem, brickSlabItem, tileBlock, smoothBlock, smoothStairsItem, smoothSlabItem);
        polishedBlockRecipes(recipeOutput, baseBlock, polishedBlock);
        stoneCutting(recipeOutput, baseBlock, brickBlock);
        stoneCutting(recipeOutput, baseBlock, stairsItem);
        stoneCuttingSlabs(recipeOutput, baseBlock, slabItem);
        stoneCutting(recipeOutput, baseBlock, brickStairsItem);
        stoneCuttingSlabs(recipeOutput, baseBlock, brickSlabItem);
        stoneCutting(recipeOutput, baseBlock, chiseledBlock);
        stoneCutting(recipeOutput,baseBlock, pillarBlock);
        stoneCutting(recipeOutput, baseBlock, tileBlock);
        smeltingRecipe(recipeOutput, baseBlock, smoothBlock, 0.1f);
    }
    protected static void stoneVariantRecipesBuilder(RecipeOutput recipeOutput,
                                                     ItemLike baseBlock, ItemLike polishedBlock, ItemLike polishedWallItem,
                                                     ItemLike brickBlock, ItemLike stairItem, ItemLike slabItem, ItemLike wallItem,
                                                     ItemLike chiseledBlock) {
        wallRecipe(recipeOutput, polishedBlock, polishedWallItem);
        stoneCutting(recipeOutput, baseBlock, polishedWallItem);
        stoneCutting(recipeOutput, polishedBlock, polishedWallItem);
        stairSlabWallRecipes(recipeOutput, brickBlock, stairItem, slabItem, wallItem);
        stairSlabWallStoneCutting(recipeOutput, baseBlock, stairItem, slabItem, wallItem);
        stairSlabWallStoneCutting(recipeOutput, polishedBlock, stairItem, slabItem, wallItem);
        brickPolishedRecipes(recipeOutput, baseBlock, polishedBlock, brickBlock);
        chiseledBlockRecipe(recipeOutput, brickBlock, slabItem, chiseledBlock);
        stoneCutting(recipeOutput, baseBlock, chiseledBlock);
        stoneCutting(recipeOutput, polishedBlock, chiseledBlock);
    }
    protected static void dripstoneRecipesBuilder(RecipeOutput recipeOutput,
                                                  ItemLike baseBlock, ItemLike baseStairsItem, ItemLike baseSlabItem, ItemLike baseWallItem,
                                                  ItemLike polishedBlock, ItemLike polishedStairsItem, ItemLike polishedSlabItem, ItemLike polishedWallItem,
                                                  ItemLike brickBlock, ItemLike brickStairItem, ItemLike brickSlabItem, ItemLike brickWallItem,
                                                  ItemLike chiseledBlock) {
        stairSlabWallRecipes(recipeOutput, baseBlock, baseStairsItem, baseSlabItem, baseWallItem);
        polishedBlockRecipes(recipeOutput, baseBlock, polishedBlock);
        stairSlabWallRecipes(recipeOutput, polishedBlock, polishedStairsItem, polishedSlabItem, polishedWallItem);
        stairSlabWallStoneCutting(recipeOutput, baseBlock, polishedStairsItem, polishedSlabItem, polishedWallItem);
        brickPolishedRecipes(recipeOutput, baseBlock, polishedBlock, brickBlock);
        stairSlabWallRecipes(recipeOutput, brickBlock, brickStairItem, brickSlabItem, brickWallItem);
        stairSlabWallStoneCutting(recipeOutput, baseBlock, brickStairItem, brickSlabItem, brickWallItem);
        stairSlabWallStoneCutting(recipeOutput, polishedBlock, brickStairItem, brickSlabItem, brickWallItem);
        chiseledBlockRecipe(recipeOutput, brickBlock, brickSlabItem, chiseledBlock);
        stoneCutting(recipeOutput, baseBlock, chiseledBlock);
        stoneCutting(recipeOutput, polishedBlock, chiseledBlock);
    }
    protected static void brickVariantRecipesBuilder(RecipeOutput recipeOutput, ItemLike baseBlock,
                                                     ItemLike mossyBlock, ItemLike mossyStairItem, ItemLike mossySlabItem, ItemLike mossyWallItem,
                                                     ItemLike crackedBlock, ItemLike crackedStairItem, ItemLike crackedSlabItem, ItemLike crackedWallItem,
                                                     ItemLike ruinedBlock, ItemLike ruinedStairsItem, ItemLike ruinedSlabItem, ItemLike ruinedWallItem
                                                     ) {
        mossyRecipes(recipeOutput, baseBlock, mossyBlock);
        stairSlabWallRecipes(recipeOutput, mossyBlock, mossyStairItem, mossySlabItem, mossyWallItem);
        smeltingRecipe(recipeOutput, baseBlock, crackedBlock, 0.1f);
        stairSlabWallRecipes(recipeOutput, crackedBlock, crackedStairItem, crackedSlabItem, crackedWallItem);
        stairSlabWallRecipes(recipeOutput, ruinedBlock, ruinedStairsItem, ruinedSlabItem, ruinedWallItem);
    }
    protected static void prismarineRecipeBuilder(RecipeOutput recipeOutput, ItemLike baseBlock,
                                                  ItemLike polishedBlock, ItemLike polishedStairsItem, ItemLike polishedSlabItem, ItemLike polishedWallItem,
                                                  ItemLike brickBlock, ItemLike brickSlabItem, ItemLike brickWallItem, ItemLike chiseledBlock, ItemLike darkBlock, ItemLike darkWallItem) {
        polishedBlockRecipes(recipeOutput, baseBlock, polishedBlock);
        stairSlabWallRecipes(recipeOutput, polishedBlock, polishedStairsItem, polishedSlabItem, polishedWallItem);
        stairSlabWallStoneCutting(recipeOutput, baseBlock, polishedStairsItem, polishedSlabItem, polishedWallItem);
        wallRecipe(recipeOutput, brickBlock, brickWallItem);
        stoneCutting(recipeOutput, brickBlock, brickWallItem);
        chiseledBlockRecipe(recipeOutput, brickBlock, brickSlabItem, chiseledBlock);
        wallRecipe(recipeOutput, darkBlock, darkWallItem);
        stoneCutting(recipeOutput, darkBlock, darkWallItem);
    }
    protected static void elderPrismarineRecipeBuilder(RecipeOutput recipeOutput,
                                                       ItemLike baseItem, ItemLike baseBlock, ItemLike baseStairsItem, ItemLike baseSlabItem, ItemLike baseWallItem, ItemLike lanternBlock,
                                                       ItemLike polishedBlock, ItemLike polishedStairsItem, ItemLike polishedSlabItem, ItemLike polishedWallItem,
                                                       ItemLike brickBlock, ItemLike brickStairsItem, ItemLike brickSlabItem, ItemLike brickWallItem, ItemLike chiseledBlock,
                                                       ItemLike darkBlock, ItemLike darkStairsItem, ItemLike darkSlabItem, ItemLike darkWallItem) {
        ShapedRecipeBuilder.shaped(RecipeCategory.BUILDING_BLOCKS, lanternBlock, 1)
                .pattern("#C#")
                .pattern("CCC")
                .pattern("#C#")
                .define('#', baseItem)
                .define('C', Items.PRISMARINE_CRYSTALS)
                .unlockedBy(getHasName(baseItem), has(baseItem))
                .save(recipeOutput);
        ShapedRecipeBuilder.shaped(RecipeCategory.BUILDING_BLOCKS, baseBlock, 1)
                .pattern("##")
                .pattern("##")
                .define('#', baseItem)
                .unlockedBy(getHasName(baseItem), has(baseItem))
                .save(recipeOutput);
        stairSlabWallRecipes(recipeOutput, baseBlock, baseStairsItem, baseSlabItem, baseWallItem);
        polishedBlockRecipes(recipeOutput, baseBlock, polishedBlock);
        stairSlabWallRecipes(recipeOutput, polishedBlock, polishedStairsItem, polishedSlabItem, polishedWallItem);
        stairSlabWallStoneCutting(recipeOutput, baseBlock, polishedStairsItem, polishedSlabItem, polishedWallItem);
        ShapedRecipeBuilder.shaped(RecipeCategory.BUILDING_BLOCKS, brickBlock, 1)
                .pattern("###")
                .pattern("###")
                .pattern("###")
                .define('#', baseItem)
                .unlockedBy(getHasName(baseItem), has(baseItem))
                .save(recipeOutput);
        stairSlabWallRecipes(recipeOutput, brickBlock, brickStairsItem, brickSlabItem, brickWallItem);
        chiseledBlockRecipe(recipeOutput, brickBlock, brickSlabItem, chiseledBlock);
        ShapedRecipeBuilder.shaped(RecipeCategory.BUILDING_BLOCKS, darkBlock, 1)
                .pattern("###")
                .pattern("#B#")
                .pattern("###")
                .define('#', baseItem)
                .define('B', Tags.Items.DYES_BLACK)
                .unlockedBy(getHasName(baseItem), has(baseItem))
                .save(recipeOutput);
        stairSlabWallRecipes(recipeOutput, darkBlock, darkStairsItem, darkSlabItem, darkWallItem);
    }
    protected static void stairRecipe(RecipeOutput recipeOutput, ItemLike baseBlock, ItemLike stairsItem) {
        ShapedRecipeBuilder.shaped(RecipeCategory.BUILDING_BLOCKS, stairsItem, 6)
                .pattern("#  ")
                .pattern("## ")
                .pattern("###")
                .define('#', baseBlock)
                .unlockedBy(getHasName(baseBlock), has(baseBlock))
                .save(recipeOutput);
    }
    protected static void slabRecipe(RecipeOutput recipeOutput, ItemLike baseBlock, ItemLike slabItem) {
        ShapedRecipeBuilder.shaped(RecipeCategory.BUILDING_BLOCKS, slabItem, 6)
                .pattern("###")
                .define('#', baseBlock)
                .unlockedBy(getHasName(baseBlock), has(baseBlock))
                .save(recipeOutput);
    }
    protected static void wallRecipe(RecipeOutput recipeOutput, ItemLike baseBlock, ItemLike wallItem) {
        ShapedRecipeBuilder.shaped(RecipeCategory.BUILDING_BLOCKS, wallItem, 6)
                .pattern("###")
                .pattern("###")
                .define('#', baseBlock)
                .unlockedBy(getHasName(baseBlock), has(baseBlock))
                .save(recipeOutput);
    }
    protected static void twoByTwoConvert(RecipeOutput recipeOutput, ItemLike baseBlock, ItemLike resultBlock) {
        ShapedRecipeBuilder.shaped(RecipeCategory.BUILDING_BLOCKS, resultBlock, 4)
                .pattern("##")
                .pattern("##")
                .define('#', baseBlock)
                .unlockedBy(getHasName(baseBlock), has(baseBlock))
                .save(recipeOutput);
    }
    protected static void twoByTwoPackingUnpacking(RecipeOutput recipeOutput, RecipeCategory recipeCategory, ItemLike baseItem, ItemLike resultBlock) {
        ShapedRecipeBuilder.shaped(recipeCategory, resultBlock, 1)
                .pattern("##")
                .pattern("##")
                .define('#', baseItem)
                .unlockedBy(getHasName(baseItem), has(baseItem))
                .save(recipeOutput);
        ShapelessRecipeBuilder.shapeless(recipeCategory, baseItem, 4)
                .requires(resultBlock)
                .unlockedBy(getHasName(resultBlock), has(resultBlock))
                .save(recipeOutput);
    }
    protected static void compactingUnpacking(RecipeOutput recipeOutput, RecipeCategory recipeCategory, ItemLike baseItem, ItemLike resultBlock) {
        ShapedRecipeBuilder.shaped(recipeCategory, resultBlock, 1)
                .pattern("###")
                .pattern("###")
                .pattern("###")
                .define('#', baseItem)
                .unlockedBy(getHasName(baseItem), has(baseItem))
                .save(recipeOutput);
        ShapelessRecipeBuilder.shapeless(recipeCategory, baseItem, 9)
                .requires(resultBlock)
                .unlockedBy(getHasName(resultBlock), has(resultBlock))
                .save(recipeOutput);
    }
    protected static void mossyRecipe(RecipeOutput recipeOutput, ItemLike baseBlock, ItemLike resultBlock, ItemLike mossAdditive) {
        ShapelessRecipeBuilder.shapeless(RecipeCategory.BUILDING_BLOCKS, resultBlock, 1)
                .requires(baseBlock)
                .requires(mossAdditive)
                .group(getItemName(resultBlock))
                .unlockedBy(getHasName(baseBlock), has(baseBlock))
                .save(recipeOutput,getItemName(resultBlock) + "_" + getItemName(mossAdditive));
    }
    protected static void mossyRecipes(RecipeOutput recipeOutput, ItemLike baseBlock, ItemLike resultBlock) {
        mossyRecipe(recipeOutput, baseBlock, resultBlock, Blocks.MOSS_BLOCK);
        mossyRecipe(recipeOutput, baseBlock, resultBlock, Blocks.VINE);
        mossyRecipe(recipeOutput, baseBlock, resultBlock, ModItems.MOSS_CLUMP.get());
    }
    protected static void polishedBlockRecipes(RecipeOutput recipeOutput, ItemLike baseBlock, ItemLike polished) {
        twoByTwoConvert(recipeOutput, baseBlock, polished);
        stoneCutting(recipeOutput, baseBlock, polished);
    }
    protected static void brickPolishedRecipes(RecipeOutput recipeOutput, ItemLike baseBlock, ItemLike polishedBlock, ItemLike brickBlock) {
        twoByTwoConvert(recipeOutput, polishedBlock, brickBlock);
        stoneCutting(recipeOutput, baseBlock, brickBlock);
        stoneCutting(recipeOutput, polishedBlock, brickBlock);
    }
    protected static void stairSlabRecipes(RecipeOutput recipeOutput, ItemLike baseBlock, ItemLike stairsItem, ItemLike slabItem) {
        stairRecipe(recipeOutput, baseBlock, stairsItem);
        slabRecipe(recipeOutput, baseBlock, slabItem);
        stoneCutting(recipeOutput, baseBlock, stairsItem);
        stoneCuttingSlabs(recipeOutput, baseBlock, slabItem);
    }
    protected static void brickStairSlabRecipes(RecipeOutput recipeOutput, ItemLike brickBlock, ItemLike baseBlock, ItemLike stairsItem, ItemLike slabItem) {
        stairSlabRecipes(recipeOutput, brickBlock, stairsItem, slabItem);
        stoneCutting(recipeOutput, baseBlock, stairsItem);
        stoneCuttingSlabs(recipeOutput, baseBlock, slabItem);
    }
    protected static void stairSlabWallRecipes(RecipeOutput recipeOutput, ItemLike baseBlock, ItemLike stairsItem, ItemLike slabItem, ItemLike wallItem) {
        stairRecipe(recipeOutput, baseBlock, stairsItem);
        slabRecipe(recipeOutput, baseBlock, slabItem);
        wallRecipe(recipeOutput, baseBlock, wallItem);
        stairSlabWallStoneCutting(recipeOutput, baseBlock, stairsItem, slabItem, wallItem);
    }
    protected static void stairSlabWallStoneCutting(RecipeOutput recipeOutput, ItemLike baseBlock, ItemLike stairsItem, ItemLike slabItem, ItemLike wallItem) {
        stoneCutting(recipeOutput, baseBlock, stairsItem);
        stoneCuttingSlabs(recipeOutput, baseBlock, slabItem);
        stoneCutting(recipeOutput, baseBlock, wallItem);
    }
    protected static void chiseledBlockRecipe(RecipeOutput recipeOutput, ItemLike baseBlock, ItemLike baseSlab, ItemLike chiseledBlock) {
        ShapedRecipeBuilder.shaped(RecipeCategory.BUILDING_BLOCKS, chiseledBlock, 1)
                .pattern("#")
                .pattern("#")
                .define('#', baseSlab)
                .unlockedBy(getHasName(baseBlock), has(baseBlock))
                .save(recipeOutput);
        stoneCutting(recipeOutput, baseBlock, chiseledBlock);
    }
    protected static void pillarBlockRecipe(RecipeOutput recipeOutput, ItemLike baseBlock, ItemLike pillarBlock) {
        ShapedRecipeBuilder.shaped(RecipeCategory.BUILDING_BLOCKS, pillarBlock, 2)
                .pattern("#")
                .pattern("#")
                .define('#', baseBlock)
                .unlockedBy(getHasName(baseBlock), has(baseBlock))
                .save(recipeOutput);
        stoneCutting(recipeOutput, baseBlock, pillarBlock);
    }
    protected static void smeltingRecipe(RecipeOutput recipeOutput, ItemLike baseBlock, ItemLike result, Float experience) {
        SimpleCookingRecipeBuilder.generic(Ingredient.of(baseBlock), RecipeCategory.BUILDING_BLOCKS, result, experience, 200, RecipeSerializer.SMELTING_RECIPE, SmeltingRecipe::new)
                .group(getItemName(result))
                .unlockedBy(getHasName(baseBlock), has(baseBlock))
                .save(recipeOutput, getItemName(result) + "_from" + "_" + getItemName(baseBlock));
    }
    protected static void stoneCutting(RecipeOutput recipeOutput, ItemLike baseBlock, ItemLike resultBlock) {
        SingleItemRecipeBuilder.stonecutting(Ingredient.of(baseBlock), RecipeCategory.BUILDING_BLOCKS, resultBlock, 1)
                .unlockedBy(getHasName(baseBlock), has(baseBlock))
                .save(recipeOutput,getConversionRecipeName(resultBlock, baseBlock) + "_stonecutting");
    }
    protected static void stoneCuttingSlabs(RecipeOutput recipeOutput, ItemLike baseBlock, ItemLike resultBlock) {
        SingleItemRecipeBuilder.stonecutting(Ingredient.of(baseBlock), RecipeCategory.BUILDING_BLOCKS, resultBlock, 2)
                .unlockedBy(getHasName(baseBlock), has(baseBlock))
                .save(recipeOutput,getConversionRecipeName(resultBlock, baseBlock) + "_stonecutting");
    }
}
