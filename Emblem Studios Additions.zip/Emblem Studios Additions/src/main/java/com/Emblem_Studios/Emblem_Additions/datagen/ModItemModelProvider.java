package com.Emblem_Studios.Emblem_Additions.datagen;

import com.Emblem_Studios.Emblem_Additions.Emblem_Additions;
import com.Emblem_Studios.Emblem_Additions.block.ModBlocks;
import com.Emblem_Studios.Emblem_Additions.item.ModItems;
import net.minecraft.core.Registry;
import net.minecraft.data.PackOutput;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.client.model.generators.ItemModelProvider;
import net.minecraftforge.common.data.ExistingFileHelper;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItemModelProvider extends ItemModelProvider {
    public ModItemModelProvider(PackOutput output, ExistingFileHelper existingFileHelper) {
        super(output, Emblem_Additions.MOD_ID, existingFileHelper);
    }

    @Override
    protected void registerModels() {
        basicItem(ModItems.MOSS_CLUMP.get());
        basicItem(ModItems.ELDER_PRISMARINE_SHARD.get());
        basicItem(ModItems.ROSE_QUARTZ.get());
        basicItem(ModItems.SMOKY_QUARTZ.get());
        basicItem(ModItems.SOUL_QUARTZ.get());
        basicItem(ModItems.QUARTZ_CHISEL.get());
        basicItem(ModItems.BLANK_SMITHING_TEMPLATE.get());
        //basicItem(ModItems..get());

        wallItemVanilla(ModBlocks.CRACKED_STONE_BRICK_WALL, Blocks.CRACKED_STONE_BRICKS);
        wallItemVanilla(ModBlocks.CRACKED_DEEPSLATE_BRICK_WALL, Blocks.CRACKED_DEEPSLATE_BRICKS);
        wallItemVanilla(ModBlocks.CRACKED_DEEPSLATE_TILE_WALL, Blocks.CRACKED_DEEPSLATE_TILES);
        wallItemVanilla(ModBlocks.POLISHED_GRANITE_WALL, Blocks.POLISHED_GRANITE);
        wallItemVanilla(ModBlocks.POLISHED_DIORITE_WALL, Blocks.POLISHED_DIORITE);
        wallItemVanilla(ModBlocks.POLISHED_ANDESITE_WALL, Blocks.POLISHED_ANDESITE);
        wallItemVanilla(ModBlocks.DRIPSTONE_WALL, Blocks.DRIPSTONE_BLOCK);
        wallItemVanilla(ModBlocks.PRISMARINE_BRICK_WALL, Blocks.PRISMARINE_BRICKS);
        wallItemVanilla(ModBlocks.DARK_PRISMARINE_WALL, Blocks.DARK_PRISMARINE);

        wallItem(ModBlocks.MOSSY_COBBLED_DEEPSLATE_WALL, ModBlocks.MOSSY_COBBLED_DEEPSLATE);
        wallItem(ModBlocks.MOSSY_DEEPSLATE_BRICK_WALL, ModBlocks.MOSSY_DEEPSLATE_BRICKS);
        wallItem(ModBlocks.MOSSY_DEEPSLATE_TILE_WALL, ModBlocks.MOSSY_DEEPSLATE_TILES);
        wallItem(ModBlocks.GRANITE_BRICK_WALL, ModBlocks.GRANITE_BRICKS);
        wallItem(ModBlocks.DIORITE_BRICK_WALL, ModBlocks.DIORITE_BRICKS);
        wallItem(ModBlocks.ANDESITE_BRICK_WALL, ModBlocks.ANDESITE_BRICKS);
        wallItem(ModBlocks.POLISHED_DRIPSTONE_WALL, ModBlocks.POLISHED_DRIPSTONE);
        wallItem(ModBlocks.DRIPSTONE_BRICK_WALL, ModBlocks.DRIPSTONE_BRICKS);
        wallItem(ModBlocks.MOSSY_BRICK_WALL, ModBlocks.MOSSY_BRICKS);
        wallItem(ModBlocks.CRACKED_BRICK_WALL, ModBlocks.CRACKED_BRICKS);
        wallItem(ModBlocks.RUINED_BRICK_WALL, ModBlocks.RUINED_BRICKS);
        wallItem(ModBlocks.POLISHED_PRISMARINE_WALL, ModBlocks.POLISHED_PRISMARINE);
        wallItem(ModBlocks.ELDER_PRISMARINE_WALL, ModBlocks.ELDER_PRISMARINE);
        wallItem(ModBlocks.POLISHED_ELDER_PRISMARINE_WALL, ModBlocks.POLISHED_ELDER_PRISMARINE);
        wallItem(ModBlocks.ELDER_PRISMARINE_BRICK_WALL, ModBlocks.ELDER_PRISMARINE_BRICKS);
        wallItem(ModBlocks.DARK_ELDER_PRISMARINE_WALL, ModBlocks.DARK_ELDER_PRISMARINE);
    }

    public void wallItem(RegistryObject<? extends Block> block, RegistryObject<Block> baseBlock) {
        this.withExistingParent(ForgeRegistries.BLOCKS.getKey(block.get()).getPath(), mcLoc("block/wall_inventory"))
                .texture("wall", ResourceLocation.fromNamespaceAndPath(Emblem_Additions.MOD_ID,
                        "block/" + ForgeRegistries.BLOCKS.getKey(baseBlock.get()).getPath()));
    } //Modded Walls
    public void wallItemVanilla(RegistryObject<? extends Block> block, Block baseBlock) {
        this.withExistingParent(ForgeRegistries.BLOCKS.getKey(block.get()).getPath(), mcLoc("block/wall_inventory"))
                .texture("wall", ResourceLocation.fromNamespaceAndPath(ResourceLocation.DEFAULT_NAMESPACE,
                        "block/" + ForgeRegistries.BLOCKS.getKey(baseBlock).getPath()));
    } //Walls for Vanilla Blocks
}
