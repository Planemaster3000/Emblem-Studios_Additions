package com.Emblem_Studios.Emblem_Additions.item;

import com.Emblem_Studios.Emblem_Additions.Emblem_Additions;
import com.Emblem_Studios.Emblem_Additions.block.ModBlocks;
import com.Emblem_Studios.Emblem_Additions.item.custom.FuelBlockItem;
import com.Emblem_Studios.Emblem_Additions.item.custom.MossClumpItem;
import com.Emblem_Studios.Emblem_Additions.item.custom.QuartzChisel;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, Emblem_Additions.MOD_ID);

    public static final RegistryObject<Item> MOSS_CLUMP = ITEMS.register("moss_clump",
            () -> new MossClumpItem(new Item.Properties()));

    public static final RegistryObject<Item> ELDER_PRISMARINE_SHARD = ITEMS.register("elder_prismarine_shard",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> ROSE_QUARTZ = ITEMS.register("rose_quartz",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> SMOKY_QUARTZ = ITEMS.register("smoky_quartz",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> SOUL_QUARTZ = ITEMS.register("soul_quartz",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> BLANK_SMITHING_TEMPLATE = ITEMS.register("blank_smithing_template",
            () -> new Item(new Item.Properties().rarity(Rarity.UNCOMMON)));

    public static final RegistryObject<Item> QUARTZ_CHISEL = ITEMS.register("quartz_chisel",
            () -> new QuartzChisel(new Item.Properties().durability(128)));

    //Block Items
    public static final RegistryObject<Item> BLAZE_BLOCK = ITEMS.register("blaze_block",
            () -> new FuelBlockItem(ModBlocks.BLAZE_BLOCK.get(), new Item.Properties().fireResistant(), 24000));



    public static void register(IEventBus eventBus) {
        ITEMS.register(eventBus);
    }
}
