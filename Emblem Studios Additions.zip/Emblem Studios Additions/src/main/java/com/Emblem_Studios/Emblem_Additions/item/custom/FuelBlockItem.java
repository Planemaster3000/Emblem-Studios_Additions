package com.Emblem_Studios.Emblem_Additions.item.custom;

import net.minecraft.world.item.*;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.Block;
import org.jetbrains.annotations.Nullable;

public class FuelBlockItem extends BlockItem {
    @Deprecated
    private final Block block;
    private int burnTime = 0;

    public FuelBlockItem(Block pBlock, Item.Properties pProperties, int burnTime) {
        super(pBlock, pProperties);
        this.block = pBlock;
        this.burnTime = burnTime;
    }

    @Override
    public int getBurnTime(ItemStack itemStack, @Nullable RecipeType<?> recipeType) {
        return this.burnTime;
    }
}
