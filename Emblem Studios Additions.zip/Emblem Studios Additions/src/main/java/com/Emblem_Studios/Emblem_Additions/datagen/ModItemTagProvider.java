package com.Emblem_Studios.Emblem_Additions.datagen;

import com.Emblem_Studios.Emblem_Additions.Emblem_Additions;
import com.Emblem_Studios.Emblem_Additions.block.ModBlocks;
import com.Emblem_Studios.Emblem_Additions.item.ModItems;
import com.Emblem_Studios.Emblem_Additions.utility.ModTags;
import net.minecraft.core.HolderLookup;
import net.minecraft.data.PackOutput;
import net.minecraft.data.tags.ItemTagsProvider;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.common.data.ExistingFileHelper;
import org.jetbrains.annotations.Nullable;

import java.util.concurrent.CompletableFuture;

public class ModItemTagProvider extends ItemTagsProvider {
    public ModItemTagProvider(PackOutput pOutput, CompletableFuture<HolderLookup.Provider> pLookupProvider, CompletableFuture<TagLookup<Block>> pBlockTags, @Nullable ExistingFileHelper existingFileHelper) {
        super(pOutput, pLookupProvider, pBlockTags, Emblem_Additions.MOD_ID, existingFileHelper);
    }

    @Override
    protected void addTags(HolderLookup.Provider pProvider) {
        tag(ModTags.Items.QUARTZ_CHISELS)
                .add(ModItems.QUARTZ_CHISEL.get());
        tag(ModTags.Items.QUARTZ_CRAFTING_BASIC)
                .add(Items.QUARTZ)
                .add(ModItems.ROSE_QUARTZ.get())
                .add(ModItems.SMOKY_QUARTZ.get());
        tag(ModTags.Items.QUARTZ_CRAFTING_ALL)
                .add(Items.QUARTZ)
                .add(ModItems.ROSE_QUARTZ.get())
                .add(ModItems.SMOKY_QUARTZ.get())
                .add(ModItems.SOUL_QUARTZ.get())
                .add(Items.AMETHYST_SHARD);
        tag(ModTags.Items.QUARTZ_BLOCKS_CRAFTING_BASIC)
                .add(Items.QUARTZ_BLOCK)
                .add(ModBlocks.ROSE_QUARTZ_BLOCK.get().asItem())
                .add(ModBlocks.SMOKY_QUARTZ_BLOCK.get().asItem());
        tag(ModTags.Items.QUARTZ_BLOCKS_CRAFTING_ALL)
                .add(Items.QUARTZ_BLOCK)
                .add(ModBlocks.ROSE_QUARTZ_BLOCK.get().asItem())
                .add(ModBlocks.SMOKY_QUARTZ_BLOCK.get().asItem())
                .add(ModBlocks.SOUL_QUARTZ_BLOCK.get().asItem())
                .add(Items.AMETHYST_BLOCK)
                .add(ModBlocks.POLISHED_AMETHYST.get().asItem());
    }
}
