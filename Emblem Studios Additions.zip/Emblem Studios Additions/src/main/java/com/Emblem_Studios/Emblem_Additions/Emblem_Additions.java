package com.Emblem_Studios.Emblem_Additions;

import com.Emblem_Studios.Emblem_Additions.block.ModBlocks;
import com.Emblem_Studios.Emblem_Additions.item.ModCreativeModeTabs;
import com.Emblem_Studios.Emblem_Additions.item.ModItems;
import com.mojang.logging.LogUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.ForgeRegistries;
import org.slf4j.Logger;

import static com.Emblem_Studios.Emblem_Additions.block.ModBlocks.*;
import static com.Emblem_Studios.Emblem_Additions.item.ModItems.*;

// The value here should match an entry in the META-INF/mods.toml file
@Mod(Emblem_Additions.MOD_ID)
public class Emblem_Additions
{
    public static final String MOD_ID = "emblem_stuff";
    // Directly reference a slf4j logger
    public static final Logger LOGGER = LogUtils.getLogger();



    public Emblem_Additions(FMLJavaModLoadingContext context)
    {
        IEventBus modEventBus = context.getModEventBus();

        // Register the commonSetup method for modloading
        modEventBus.addListener(this::commonSetup);

        // Register ourselves for server and other game events we are interested in
        MinecraftForge.EVENT_BUS.register(this);

        ModCreativeModeTabs.register(modEventBus);

        ModItems.register(modEventBus);
        ModBlocks.register(modEventBus);

        // Register the item to a creative tab
        modEventBus.addListener(this::addCreative);

        // Register our mod's ForgeConfigSpec so that Forge can create and load the config file for us
        context.registerConfig(ModConfig.Type.COMMON, Config.SPEC);
    }

    private void commonSetup(final FMLCommonSetupEvent event)
    {
        // Some common setup code
        LOGGER.info("HELLO FROM COMMON SETUP");

        if (Config.logDirtBlock)
            LOGGER.info("DIRT BLOCK >> {}", ForgeRegistries.BLOCKS.getKey(Blocks.DIRT));

        LOGGER.info(Config.magicNumberIntroduction + Config.magicNumber);

        Config.items.forEach((item) -> LOGGER.info("ITEM >> {}", item.toString()));
    }

    // Add the example block item to the building blocks tab
    private void addCreative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.INGREDIENTS) {
            event.accept(MOSS_CLUMP);
            event.accept(ELDER_PRISMARINE_SHARD);
            event.accept(ROSE_QUARTZ);
            event.accept(SMOKY_QUARTZ);
            event.accept(SOUL_QUARTZ);
            event.accept(BLANK_SMITHING_TEMPLATE);
        }
        if (event.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
            event.accept(CRACKED_STONE_BRICK_STAIRS);
            event.accept(CRACKED_STONE_BRICK_SLAB);
            event.accept(CRACKED_STONE_BRICK_WALL);
            event.accept(MOSSY_CHISILED_STONE_BRICKS);
            event.accept(CRACKED_CHISILED_STONE_BRICKS);
            event.accept(STONE_BRICK_PILLAR);
            event.accept(MOSSY_STONE_BRICK_PILLAR);
            event.accept(CRACKED_STONE_BRICK_PILLAR);
            event.accept(MOSSY_COBBLED_DEEPSLATE);
            event.accept(MOSSY_COBBLED_DEEPSLATE_STAIRS);
            event.accept(MOSSY_COBBLED_DEEPSLATE_SLAB);
            event.accept(MOSSY_COBBLED_DEEPSLATE_WALL);
            event.accept(MOSSY_DEEPSLATE_BRICKS);
            event.accept(MOSSY_DEEPSLATE_BRICK_STAIRS);
            event.accept(MOSSY_DEEPSLATE_BRICK_SLAB);
            event.accept(MOSSY_DEEPSLATE_BRICK_WALL);
            event.accept(CRACKED_DEEPSLATE_BRICK_STAIRS);
            event.accept(CRACKED_DEEPSLATE_BRICK_SLAB);
            event.accept(CRACKED_DEEPSLATE_BRICK_WALL);
            event.accept(MOSSY_DEEPSLATE_TILES);
            event.accept(MOSSY_DEEPSLATE_TILE_STAIRS);
            event.accept(MOSSY_DEEPSLATE_TILE_SLAB);
            event.accept(MOSSY_DEEPSLATE_TILE_WALL);
            event.accept(CRACKED_DEEPSLATE_TILE_STAIRS);
            event.accept(CRACKED_DEEPSLATE_TILE_SLAB);
            event.accept(CRACKED_DEEPSLATE_TILE_WALL);
            event.accept(POLISHED_GRANITE_WALL);
            event.accept(GRANITE_BRICKS);
            event.accept(GRANITE_BRICK_STAIRS);
            event.accept(GRANITE_BRICK_SLAB);
            event.accept(GRANITE_BRICK_WALL);
            event.accept(CHISELED_GRANITE_BRICKS);
            event.accept(POLISHED_DIORITE_WALL);
            event.accept(DIORITE_BRICKS);
            event.accept(DIORITE_BRICK_STAIRS);
            event.accept(DIORITE_BRICK_SLAB);
            event.accept(DIORITE_BRICK_WALL);
            event.accept(CHISELED_DIORITE_BRICKS);
            event.accept(POLISHED_ANDESITE_WALL);
            event.accept(ANDESITE_BRICKS);
            event.accept(ANDESITE_BRICK_STAIRS);
            event.accept(ANDESITE_BRICK_SLAB);
            event.accept(ANDESITE_BRICK_WALL);
            event.accept(CHISELED_ANDESITE_BRICKS);
            event.accept(DRIPSTONE_STAIRS);
            event.accept(DRIPSTONE_SLAB);
            event.accept(DRIPSTONE_WALL);
            event.accept(POLISHED_DRIPSTONE);
            event.accept(POLISHED_DRIPSTONE_STAIRS);
            event.accept(POLISHED_DRIPSTONE_SLAB);
            event.accept(POLISHED_DRIPSTONE_WALL);
            event.accept(DRIPSTONE_BRICKS);
            event.accept(DRIPSTONE_BRICK_STAIRS);
            event.accept(DRIPSTONE_BRICK_SLAB);
            event.accept(DRIPSTONE_BRICK_WALL);
            event.accept(CHISELED_DRIPSTONE_BRICKS);
            event.accept(MOSSY_BRICKS);
            event.accept(MOSSY_BRICK_STAIRS);
            event.accept(MOSSY_BRICK_SLAB);
            event.accept(MOSSY_BRICK_WALL);
            event.accept(CRACKED_BRICKS);
            event.accept(CRACKED_BRICK_STAIRS);
            event.accept(CRACKED_BRICK_SLAB);
            event.accept(CRACKED_BRICK_WALL);
            event.accept(RUINED_BRICKS);
            event.accept(RUINED_BRICK_STAIRS);
            event.accept(RUINED_BRICK_SLAB);
            event.accept(RUINED_BRICK_WALL);
            event.accept(POLISHED_PRISMARINE);
            event.accept(POLISHED_PRISMARINE_STAIRS);
            event.accept(POLISHED_PRISMARINE_SLAB);
            event.accept(POLISHED_PRISMARINE_WALL);
            event.accept(PRISMARINE_BRICK_WALL);
            event.accept(CHISELED_PRISMARINE_BRICKS);
            event.accept(DARK_PRISMARINE_WALL);
            event.accept(ELDER_SEA_LANTERN);
            event.accept(ELDER_PRISMARINE);
            event.accept(ELDER_PRISMARINE_STAIRS);
            event.accept(ELDER_PRISMARINE_SLAB);
            event.accept(ELDER_PRISMARINE_WALL);
            event.accept(POLISHED_ELDER_PRISMARINE);
            event.accept(POLISHED_ELDER_PRISMARINE_STAIRS);
            event.accept(POLISHED_ELDER_PRISMARINE_SLAB);
            event.accept(POLISHED_ELDER_PRISMARINE_WALL);
            event.accept(ELDER_PRISMARINE_BRICKS);
            event.accept(ELDER_PRISMARINE_BRICK_STAIRS);
            event.accept(ELDER_PRISMARINE_BRICK_SLAB);
            event.accept(ELDER_PRISMARINE_BRICK_WALL);
            event.accept(CHISELED_ELDER_PRISMARINE_BRICKS);
            event.accept(DARK_ELDER_PRISMARINE);
            event.accept(DARK_ELDER_PRISMARINE_STAIRS);
            event.accept(DARK_ELDER_PRISMARINE_SLAB);
            event.accept(DARK_ELDER_PRISMARINE_WALL);
            event.accept(QUARTZ_BRICK_STAIRS);
            event.accept(QUARTZ_BRICK_SLAB);
            event.accept(WHITE_QUARTZ_TILES);
            event.accept(ROSE_QUARTZ_BLOCK);    //Rose Quartz Blocks
            event.accept(ROSE_QUARTZ_STAIRS);
            event.accept(ROSE_QUARTZ_SLAB);
            event.accept(CHISELED_ROSE_QUARTZ_BLOCK);
            event.accept(ROSE_QUARTZ_PILLAR);
            event.accept(ROSE_QUARTZ_BRICKS);
            event.accept(ROSE_QUARTZ_BRICK_STAIRS);
            event.accept(ROSE_QUARTZ_BRICK_SLAB);
            event.accept(ROSE_QUARTZ_TILES);
            event.accept(SMOOTH_ROSE_QUARTZ);
            event.accept(SMOOTH_ROSE_QUARTZ_STAIRS);
            event.accept(SMOOTH_ROSE_QUARTZ_SLAB);
            event.accept(SMOKY_QUARTZ_BLOCK);   //Smoky Quartz Blocks
            event.accept(SMOKY_QUARTZ_STAIRS);
            event.accept(SMOKY_QUARTZ_SLAB);
            event.accept(CHISELED_SMOKY_QUARTZ_BLOCK);
            event.accept(SMOKY_QUARTZ_PILLAR);
            event.accept(SMOKY_QUARTZ_BRICKS);
            event.accept(SMOKY_QUARTZ_BRICK_STAIRS);
            event.accept(SMOKY_QUARTZ_BRICK_SLAB);
            event.accept(SMOKY_QUARTZ_TILES);
            event.accept(SMOOTH_SMOKY_QUARTZ);
            event.accept(SMOOTH_SMOKY_QUARTZ_STAIRS);
            event.accept(SMOOTH_SMOKY_QUARTZ_SLAB);
            event.accept(SOUL_QUARTZ_BLOCK);    //Soul Quartz Blocks
            event.accept(SOUL_QUARTZ_STAIRS);
            event.accept(SOUL_QUARTZ_SLAB);
            event.accept(CHISELED_SOUL_QUARTZ_BLOCK);
            event.accept(SOUL_QUARTZ_PILLAR);
            event.accept(SOUL_QUARTZ_BRICKS);
            event.accept(SOUL_QUARTZ_BRICK_STAIRS);
            event.accept(SOUL_QUARTZ_BRICK_SLAB);
            event.accept(SOUL_QUARTZ_TILES);
            event.accept(SMOOTH_SOUL_QUARTZ);
            event.accept(SMOOTH_SOUL_QUARTZ_STAIRS);
            event.accept(SMOOTH_SOUL_QUARTZ_SLAB);
            event.accept(POLISHED_AMETHYST);    //Amethyst Blocks
            event.accept(POLISHED_AMETHYST_STAIRS);
            event.accept(POLISHED_AMETHYST_SLAB);
            event.accept(CHISELED_AMETHYST_BLOCK);
            event.accept(AMETHYST_PILLAR);
            event.accept(AMETHYST_BRICKS);
            event.accept(AMETHYST_BRICK_STAIRS);
            event.accept(AMETHYST_BRICK_SLAB);
            event.accept(AMETHYST_TILES);
            event.accept(SMOOTH_AMETHYST);
            event.accept(SMOOTH_AMETHYST_STAIRS);
            event.accept(SMOOTH_AMETHYST_SLAB);
        }
        if (event.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
            event.accept(NETHER_ROSE_QUARTZ_ORE);
            event.accept(NETHER_SMOKY_QUARTZ_ORE);
        }
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(INFESTED_MOSSY_CHISILED_STONE_BRICKS);
            event.accept(INFESTED_CRACKED_CHISILED_STONE_BRICKS);
            event.accept(INFESTED_STONE_BRICK_PILLAR);
            event.accept(INFESTED_MOSSY_STONE_BRICK_PILLAR);
            event.accept(INFESTED_CRACKED_STONE_BRICK_PILLAR);
        }
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(QUARTZ_CHISEL);
        }
    }

    // You can use SubscribeEvent and let the Event Bus discover methods to call
    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event)
    {
        // Do something when the server starts
        LOGGER.info("HELLO from server starting");
    }

    // You can use EventBusSubscriber to automatically register all static methods in the class annotated with @SubscribeEvent
    @Mod.EventBusSubscriber(modid = MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ClientModEvents
    {
        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event)
        {
            // Some client setup code
            LOGGER.info("HELLO FROM CLIENT SETUP");
            LOGGER.info("MINECRAFT NAME >> {}", Minecraft.getInstance().getUser().getName());
        }
    }
}
